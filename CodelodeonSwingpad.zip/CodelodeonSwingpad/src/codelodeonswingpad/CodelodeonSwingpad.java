/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codelodeonswingpad;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Formatter;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Element;
import javax.swing.undo.UndoManager;

/**
 *
 * @author Mirza Milan Farabi
 */
public class CodelodeonSwingpad extends javax.swing.JFrame {

    /**
     * Creates new form CodelodeonSwingpad
     */
    private static JTextArea lines1;
    private static JTextArea lines2;
    private static JTextArea lines3;
    
    UndoManager manager1 = new UndoManager();
    UndoManager manager2 = new UndoManager();
    UndoManager manager3 = new UndoManager();
    
    Font font1 = new Font("Courier New", Font.PLAIN, 14);
    Font font2 = new Font("Courier New", Font.PLAIN, 16);
    Font font3 = new Font("Courier New", Font.PLAIN, 18);
    Font font4 = new Font("Courier New", Font.PLAIN, 20);
    Font font5 = new Font("Courier New", Font.PLAIN, 22);
    Font font6 = new Font("Courier New", Font.PLAIN, 24);
    Font font7 = new Font("Courier New", Font.PLAIN, 26);
    Font font8 = new Font("Courier New", Font.PLAIN, 28);
    Font font9 = new Font("Courier New", Font.PLAIN, 30);
    Font font10 = new Font("Courier New", Font.PLAIN, 32);
    
    public CodelodeonSwingpad() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Codelodeon Swingpad");
        
        jTextArea1.setDragEnabled(true);
        jTextArea2.setDragEnabled(true);
        jTextArea3.setDragEnabled(true);
        jTextArea4.setDragEnabled(true);
        
        jTextArea1.setForeground(Color.BLACK);
        jTextArea1.setBackground(Color.WHITE);
        jTextArea2.setForeground(Color.BLACK);
        jTextArea2.setBackground(Color.WHITE);
        jTextArea3.setForeground(Color.BLACK);
        jTextArea3.setBackground(Color.WHITE);
        
        LineNumberA();
        LineNumberB();
        LineNumberC();        
        
        jTextArea1.getDocument().addUndoableEditListener(new UndoableEditListener() {
            public void undoableEditHappened(UndoableEditEvent e) {
                manager1.addEdit(e.getEdit());
            }
        });
        jTextArea2.getDocument().addUndoableEditListener(new UndoableEditListener() {
            public void undoableEditHappened(UndoableEditEvent e) {
                manager2.addEdit(e.getEdit());
            }
        });
        jTextArea3.getDocument().addUndoableEditListener(new UndoableEditListener() {
            public void undoableEditHappened(UndoableEditEvent e) {
                manager3.addEdit(e.getEdit());
            }
        });
    }
    
    public void transferHTML(){
            jTextArea4.selectAll();
            jTextArea4.cut();       
            jTextArea1.paste();
    }
    
    public void transferCSS(){
            jTextArea4.selectAll();
            jTextArea4.cut();       
            jTextArea2.paste();
    }
    
    public void transferJS(){
            jTextArea4.selectAll();
            jTextArea4.cut();       
            jTextArea3.paste();
    }
    
    void Undo1() {
        try {
            manager1.undo();
        } catch (Exception ex) {
        }
    }

    void Redo1() {
        try {
            manager1.redo();
        } catch (Exception ex) {
        }
    }    
    
    void Undo2() {
        try {
            manager2.undo();
        } catch (Exception ex) {
        }
    }

    void Redo2() {
        try {
            manager2.redo();
        } catch (Exception ex) {
        }
    }    
    
    void Undo3() {
        try {
            manager3.undo();
        } catch (Exception ex) {
        }
    }

    void Redo3() {
        try {
            manager3.redo();
        } catch (Exception ex) {
        }
    }     
    
    void LineFont1() {
        lines1.setFont(font1);
        lines2.setFont(font1);
        lines3.setFont(font1);
    }

    void LineFont2() {
        lines1.setFont(font2);
        lines2.setFont(font2);
        lines3.setFont(font2);
    }    
    
    void LineFont3() {
        lines1.setFont(font3);
        lines2.setFont(font3);
        lines3.setFont(font3);
    }    
    
    void LineFont4() {
        lines1.setFont(font4);
        lines2.setFont(font4);
        lines3.setFont(font4);
    }    

    void LineFont5() {
        lines1.setFont(font5);
        lines2.setFont(font5);
        lines3.setFont(font5);
    }    

    void LineFont6() {
        lines1.setFont(font6);
        lines2.setFont(font6);
        lines3.setFont(font6);
    }    

    void LineFont7() {
        lines1.setFont(font7);
        lines2.setFont(font7);
        lines3.setFont(font7);
    }    

    void LineFont8() {
        lines1.setFont(font8);
        lines2.setFont(font8);
        lines3.setFont(font8);
    }    

    void LineFont9() {
        lines1.setFont(font9);
        lines2.setFont(font9);
        lines3.setFont(font9);
    }    

    void LineFont10() {
        lines1.setFont(font10);
        lines2.setFont(font10);
        lines3.setFont(font10);
    }    
    
    void LineNumberA() {

        lines1 = new JTextArea("1");
        lines1.setBackground(Color.LIGHT_GRAY);
        lines1.setEditable(false);
        //  Code to implement line numbers inside the JTextArea
        jTextArea1.getDocument().addDocumentListener(new DocumentListener() {
            public String getText() {
                int caretPosition = jTextArea1.getDocument().getLength();
                Element root = jTextArea1.getDocument().getDefaultRootElement();
                String text = "1" + System.getProperty("line.separator");
                for (int i = 2; i < root.getElementIndex(caretPosition) + 2; i++) {
                    text += i + System.getProperty("line.separator");
                }
                return text;
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                lines1.setText(getText());
            }

            @Override
            public void insertUpdate(DocumentEvent de) {
                lines1.setText(getText());
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                lines1.setText(getText());
            }
        });
        jScrollPane1.getViewport().add(jTextArea1);
        jScrollPane1.setRowHeaderView(lines1);

    }    
    
    void LineNumberB() {

        lines2 = new JTextArea("1");
        lines2.setBackground(Color.LIGHT_GRAY);
        lines2.setEditable(false);
        //  Code to implement line numbers inside the JTextArea
        jTextArea2.getDocument().addDocumentListener(new DocumentListener() {
            public String getText() {
                int caretPosition = jTextArea2.getDocument().getLength();
                Element root = jTextArea2.getDocument().getDefaultRootElement();
                String text = "1" + System.getProperty("line.separator");
                for (int i = 2; i < root.getElementIndex(caretPosition) + 2; i++) {
                    text += i + System.getProperty("line.separator");
                }
                return text;
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                lines2.setText(getText());
            }

            @Override
            public void insertUpdate(DocumentEvent de) {
                lines2.setText(getText());
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                lines2.setText(getText());
            }
        });
        jScrollPane2.getViewport().add(jTextArea2);
        jScrollPane2.setRowHeaderView(lines2);

    }    

    void LineNumberC() {

        lines3 = new JTextArea("1");
        lines3.setBackground(Color.LIGHT_GRAY);
        lines3.setEditable(false);
        //  Code to implement line numbers inside the JTextArea
        jTextArea3.getDocument().addDocumentListener(new DocumentListener() {
            public String getText() {
                int caretPosition = jTextArea3.getDocument().getLength();
                Element root = jTextArea3.getDocument().getDefaultRootElement();
                String text = "1" + System.getProperty("line.separator");
                for (int i = 2; i < root.getElementIndex(caretPosition) + 2; i++) {
                    text += i + System.getProperty("line.separator");
                }
                return text;
            }

            @Override
            public void changedUpdate(DocumentEvent de) {
                lines3.setText(getText());
            }

            @Override
            public void insertUpdate(DocumentEvent de) {
                lines3.setText(getText());
            }

            @Override
            public void removeUpdate(DocumentEvent de) {
                lines3.setText(getText());
            }
        });
        jScrollPane3.getViewport().add(jTextArea3);
        jScrollPane3.setRowHeaderView(lines3);

    }      
    
    //---------------------------------------------------------------------------//
    
    public void OpenHTML() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a HTML File To Open");

            File openFile = chooser.getSelectedFile();
         
            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before opening ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsHTML();

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }
            } else {

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }

            }

            Scanner reader = new Scanner(openFile);
            String contents = "";
            while (reader.hasNextLine()) {
                contents += reader.nextLine() + "\n";
            }
            reader.close();
            jTextArea1.setText(contents);

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SaveHTML() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a HTML File To Save");
            chooser.showSaveDialog(null);

            File openFile = chooser.getSelectedFile();

            if (openFile == null) {
                JOptionPane.showMessageDialog(null, "Failed To Save File, No File is Selected !", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String contents = jTextArea1.getText();
            Formatter form = new Formatter(openFile);
            form.format("%s", contents);
            form.close();

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void SaveAsHTML() {

        try {
            String s = jTextArea1.getText();
            if (s.length() > 0) {
                FileDialog fd = new FileDialog(this, "Save As", FileDialog.SAVE);
                fd.setFile("index.html");
                fd.setDirectory("");
                fd.setVisible(true);
                String path = fd.getDirectory() + fd.getFile();

                FileOutputStream fos = new FileOutputStream(path);
                System.out.println(s);
                byte[] b = s.getBytes();
                fos.write(b);
                fos.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void CloseHTML() {

        try {

            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before closing ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsHTML();
                return;
            } else if (jTextArea1 != null) {
                int output = JOptionPane.showConfirmDialog(null, "Close the File !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (output == JOptionPane.YES_OPTION) {

                } else if (jTextArea1 != null) {
                    
                    return;
                }

            }

            jTextArea1.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void NewHTML() {

        try {

            if (jTextArea1 != null) {
                int input = JOptionPane.showConfirmDialog(null, "Create New !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (input == JOptionPane.YES_OPTION) {
                    int output = JOptionPane.showConfirmDialog(null, "Do you want to save before creating New ?", "Wait !", JOptionPane.YES_NO_OPTION);

                    if (output == JOptionPane.YES_OPTION) {
                        SaveAsHTML();
                        return;

                    }

                } else if (jTextArea1 != null) {
                    
                    return;
                }

            }

            jTextArea1.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //---------------------------------------------------------------------------//      
    
    //---------------------------------------------------------------------------//
    
    public void OpenCSS() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a CSS File To Open");

            File openFile = chooser.getSelectedFile();
         
            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before opening ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsCSS();

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }
            } else {

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }

            }

            Scanner reader = new Scanner(openFile);
            String contents = "";
            while (reader.hasNextLine()) {
                contents += reader.nextLine() + "\n";
            }
            reader.close();
            jTextArea2.setText(contents);

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SaveCSS() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a CSS File To Save");
            chooser.showSaveDialog(null);

            File openFile = chooser.getSelectedFile();

            if (openFile == null) {
                JOptionPane.showMessageDialog(null, "Failed To Save File, No File is Selected !", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String contents = jTextArea2.getText();
            Formatter form = new Formatter(openFile);
            form.format("%s", contents);
            form.close();

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void SaveAsCSS() {

        try {
            String s = jTextArea2.getText();
            if (s.length() > 0) {
                FileDialog fd = new FileDialog(this, "Save As", FileDialog.SAVE);
                fd.setFile("index.css");
                fd.setDirectory("");
                fd.setVisible(true);
                String path = fd.getDirectory() + fd.getFile();

                FileOutputStream fos = new FileOutputStream(path);
                System.out.println(s);
                byte[] b = s.getBytes();
                fos.write(b);
                fos.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void CloseCSS() {

        try {

            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before closing ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsCSS();
                return;
            } else if (jTextArea2 != null) {
                int output = JOptionPane.showConfirmDialog(null, "Close the File !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (output == JOptionPane.YES_OPTION) {

                } else if (jTextArea2 != null) {
                    
                    return;
                }

            }

            jTextArea2.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void NewCSS() {

        try {

            if (jTextArea2 != null) {
                int input = JOptionPane.showConfirmDialog(null, "Create New !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (input == JOptionPane.YES_OPTION) {
                    int output = JOptionPane.showConfirmDialog(null, "Do you want to save before creating New ?", "Wait !", JOptionPane.YES_NO_OPTION);

                    if (output == JOptionPane.YES_OPTION) {
                        SaveAsCSS();
                        return;

                    }

                } else if (jTextArea2 != null) {
                    
                    return;
                }

            }

            jTextArea2.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //---------------------------------------------------------------------------//       
    
    //---------------------------------------------------------------------------//
    
    public void OpenJS() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a JavaScript File To Open");

            File openFile = chooser.getSelectedFile();
         
            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before opening ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsJS();

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }
            } else {

                chooser.showOpenDialog(null);
                openFile = chooser.getSelectedFile();
                if (openFile == null) {
                    JOptionPane.showMessageDialog(null, "Failed To Open File !", "Error", JOptionPane.ERROR_MESSAGE);
                    openFile = null;
                    return;
                }

            }

            Scanner reader = new Scanner(openFile);
            String contents = "";
            while (reader.hasNextLine()) {
                contents += reader.nextLine() + "\n";
            }
            reader.close();
            jTextArea3.setText(contents);

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SaveJS() {
        try {

            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select a JavaScript File To Save");
            chooser.showSaveDialog(null);

            File openFile = chooser.getSelectedFile();

            if (openFile == null) {
                JOptionPane.showMessageDialog(null, "Failed To Save File, No File is Selected !", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String contents = jTextArea3.getText();
            Formatter form = new Formatter(openFile);
            form.format("%s", contents);
            form.close();

            setTitle(openFile.getName() + " - " + "Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void SaveAsJS() {

        try {
            String s = jTextArea3.getText();
            if (s.length() > 0) {
                FileDialog fd = new FileDialog(this, "Save As", FileDialog.SAVE);
                fd.setFile("index.js");
                fd.setDirectory("");
                fd.setVisible(true);
                String path = fd.getDirectory() + fd.getFile();

                FileOutputStream fos = new FileOutputStream(path);
                System.out.println(s);
                byte[] b = s.getBytes();
                fos.write(b);
                fos.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void CloseJS() {

        try {

            int input = JOptionPane.showConfirmDialog(null, "Do you want to save before closing ?", "Wait !", JOptionPane.YES_NO_OPTION);

            if (input == JOptionPane.YES_OPTION) {
                SaveAsJS();
                return;
            } else if (jTextArea3 != null) {
                int output = JOptionPane.showConfirmDialog(null, "Close the File !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (output == JOptionPane.YES_OPTION) {

                } else if (jTextArea3 != null) {
                    
                    return;
                }

            }

            jTextArea3.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void NewJS() {

        try {

            if (jTextArea3 != null) {
                int input = JOptionPane.showConfirmDialog(null, "Create New !", "Wait !", JOptionPane.YES_NO_OPTION);

                if (input == JOptionPane.YES_OPTION) {
                    int output = JOptionPane.showConfirmDialog(null, "Do you want to save before creating New ?", "Wait !", JOptionPane.YES_NO_OPTION);

                    if (output == JOptionPane.YES_OPTION) {
                        SaveAsJS();
                        return;

                    }

                } else if (jTextArea3 != null) {
                    
                    return;
                }

            }

            jTextArea3.setText("");

            setTitle("Codelodeon Swingpad");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //---------------------------------------------------------------------------//        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel10 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jSplitPane1 = new javax.swing.JSplitPane();
        jSplitPane2 = new javax.swing.JSplitPane();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jToolBar1 = new javax.swing.JToolBar();
        jButtonHTMLNew = new javax.swing.JButton();
        jButtonHTMLOpen = new javax.swing.JButton();
        jButtonHTMLSave = new javax.swing.JButton();
        jButtonHTMLSaveAs = new javax.swing.JButton();
        jButtonHTMLClose = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jButtonHTMLUndo = new javax.swing.JButton();
        jButtonHTMLRedo = new javax.swing.JButton();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jDesktopPane2 = new javax.swing.JDesktopPane();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLayeredPane3 = new javax.swing.JLayeredPane();
        jToolBar2 = new javax.swing.JToolBar();
        jButtonCSSNew = new javax.swing.JButton();
        jButtonCSSOpen = new javax.swing.JButton();
        jButtonCSSSave = new javax.swing.JButton();
        jButtonCSSSaveAs = new javax.swing.JButton();
        jButtonCSSClose = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jButtonCSSUndo = new javax.swing.JButton();
        jButtonCSSRedo = new javax.swing.JButton();
        jLayeredPane4 = new javax.swing.JLayeredPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jDesktopPane3 = new javax.swing.JDesktopPane();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jLayeredPane5 = new javax.swing.JLayeredPane();
        jToolBar3 = new javax.swing.JToolBar();
        jButtonJSNew = new javax.swing.JButton();
        jButtonJSOpen = new javax.swing.JButton();
        jButtonJSSave = new javax.swing.JButton();
        jButtonJSSaveAs = new javax.swing.JButton();
        jButtonJSClose = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jButtonJSUndo = new javax.swing.JButton();
        jButtonJSRedo = new javax.swing.JButton();
        jLayeredPane6 = new javax.swing.JLayeredPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenu11 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenu12 = new javax.swing.JMenu();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem16 = new javax.swing.JMenuItem();
        jMenuItem25 = new javax.swing.JMenuItem();
        jMenu13 = new javax.swing.JMenu();
        jMenuItem26 = new javax.swing.JMenuItem();
        jMenuItem27 = new javax.swing.JMenuItem();
        jMenuItem28 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem29 = new javax.swing.JMenuItem();
        jMenuItem30 = new javax.swing.JMenuItem();
        jMenuItem31 = new javax.swing.JMenuItem();
        jMenuItem32 = new javax.swing.JMenuItem();
        jMenuItem33 = new javax.swing.JMenuItem();
        jMenuItem34 = new javax.swing.JMenuItem();
        jMenuItem35 = new javax.swing.JMenuItem();
        jMenuItem50 = new javax.swing.JMenuItem();
        jMenuItem51 = new javax.swing.JMenuItem();
        jMenuItem52 = new javax.swing.JMenuItem();
        jMenuItem53 = new javax.swing.JMenuItem();
        jMenuItem54 = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        jMenuItem36 = new javax.swing.JMenuItem();
        jMenuItem37 = new javax.swing.JMenuItem();
        jMenuItem38 = new javax.swing.JMenuItem();
        jMenuItem39 = new javax.swing.JMenuItem();
        jMenuItem40 = new javax.swing.JMenuItem();
        jMenuItem47 = new javax.swing.JMenuItem();
        jMenuItem48 = new javax.swing.JMenuItem();
        jMenuItem49 = new javax.swing.JMenuItem();
        jMenuItem55 = new javax.swing.JMenuItem();
        jMenuItem56 = new javax.swing.JMenuItem();
        jMenuItem57 = new javax.swing.JMenuItem();
        jMenuItem58 = new javax.swing.JMenuItem();
        jMenu10 = new javax.swing.JMenu();
        jMenuItem41 = new javax.swing.JMenuItem();
        jMenuItem42 = new javax.swing.JMenuItem();
        jMenuItem43 = new javax.swing.JMenuItem();
        jMenuItem44 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem45 = new javax.swing.JMenuItem();
        jMenuItem46 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuItemA = new javax.swing.JMenuItem();
        jMenuItemB = new javax.swing.JMenuItem();
        jMenuItemC = new javax.swing.JMenuItem();
        jMenuItemD = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem17 = new javax.swing.JMenuItem();
        jMenuItem18 = new javax.swing.JMenuItem();
        jMenuItem19 = new javax.swing.JMenuItem();
        jMenuItem20 = new javax.swing.JMenuItem();
        jMenuItem21 = new javax.swing.JMenuItem();
        jMenuItem22 = new javax.swing.JMenuItem();
        jMenuItem23 = new javax.swing.JMenuItem();
        jMenuItem24 = new javax.swing.JMenuItem();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenuItem15 = new javax.swing.JMenuItem();

        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jScrollPane4.setViewportView(jTextArea4);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jToolBar1.setRollover(true);

        jButtonHTMLNew.setText("New");
        jButtonHTMLNew.setFocusable(false);
        jButtonHTMLNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLNew.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLNewActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLNew);

        jButtonHTMLOpen.setText("Open");
        jButtonHTMLOpen.setFocusable(false);
        jButtonHTMLOpen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLOpen.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLOpenActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLOpen);

        jButtonHTMLSave.setText("Save");
        jButtonHTMLSave.setFocusable(false);
        jButtonHTMLSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLSaveActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLSave);

        jButtonHTMLSaveAs.setText("Save As");
        jButtonHTMLSaveAs.setFocusable(false);
        jButtonHTMLSaveAs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLSaveAs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLSaveAsActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLSaveAs);

        jButtonHTMLClose.setText("Close");
        jButtonHTMLClose.setFocusable(false);
        jButtonHTMLClose.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLClose.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLCloseActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLClose);

        jPanel8.setPreferredSize(new java.awt.Dimension(20, 23));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 203, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        jToolBar1.add(jPanel8);

        jButtonHTMLUndo.setText("<");
        jButtonHTMLUndo.setFocusable(false);
        jButtonHTMLUndo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLUndo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLUndoActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLUndo);

        jButtonHTMLRedo.setText(">");
        jButtonHTMLRedo.setFocusable(false);
        jButtonHTMLRedo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonHTMLRedo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonHTMLRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHTMLRedoActionPerformed(evt);
            }
        });
        jToolBar1.add(jButtonHTMLRedo);

        jLayeredPane1.setLayer(jToolBar1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLayeredPane2.setLayer(jScrollPane1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane2Layout = new javax.swing.GroupLayout(jLayeredPane2);
        jLayeredPane2.setLayout(jLayeredPane2Layout);
        jLayeredPane2Layout.setHorizontalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        jLayeredPane2Layout.setVerticalGroup(
            jLayeredPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
            .addComponent(jLayeredPane2, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane2))
        );

        jTabbedPane1.addTab("HTML", jPanel4);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        jDesktopPane1.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jSplitPane2.setLeftComponent(jDesktopPane1);

        jToolBar2.setRollover(true);

        jButtonCSSNew.setText("New");
        jButtonCSSNew.setFocusable(false);
        jButtonCSSNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSNew.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSNewActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSNew);

        jButtonCSSOpen.setText("Open");
        jButtonCSSOpen.setFocusable(false);
        jButtonCSSOpen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSOpen.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSOpenActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSOpen);

        jButtonCSSSave.setText("Save");
        jButtonCSSSave.setFocusable(false);
        jButtonCSSSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSSaveActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSSave);

        jButtonCSSSaveAs.setText("Save As");
        jButtonCSSSaveAs.setFocusable(false);
        jButtonCSSSaveAs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSSaveAs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSSaveAsActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSSaveAs);

        jButtonCSSClose.setText("Close");
        jButtonCSSClose.setFocusable(false);
        jButtonCSSClose.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSClose.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSCloseActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSClose);

        jPanel7.setPreferredSize(new java.awt.Dimension(20, 23));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 203, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        jToolBar2.add(jPanel7);

        jButtonCSSUndo.setText("<");
        jButtonCSSUndo.setFocusable(false);
        jButtonCSSUndo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSUndo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSUndoActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSUndo);

        jButtonCSSRedo.setText(">");
        jButtonCSSRedo.setFocusable(false);
        jButtonCSSRedo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonCSSRedo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonCSSRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCSSRedoActionPerformed(evt);
            }
        });
        jToolBar2.add(jButtonCSSRedo);

        jLayeredPane3.setLayer(jToolBar2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane3Layout = new javax.swing.GroupLayout(jLayeredPane3);
        jLayeredPane3.setLayout(jLayeredPane3Layout);
        jLayeredPane3Layout.setHorizontalGroup(
            jLayeredPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar2, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );
        jLayeredPane3Layout.setVerticalGroup(
            jLayeredPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jLayeredPane4.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane4Layout = new javax.swing.GroupLayout(jLayeredPane4);
        jLayeredPane4.setLayout(jLayeredPane4Layout);
        jLayeredPane4Layout.setHorizontalGroup(
            jLayeredPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        jLayeredPane4Layout.setVerticalGroup(
            jLayeredPane4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane3)
            .addComponent(jLayeredPane4, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jLayeredPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane4))
        );

        jTabbedPane2.addTab("CSS", jPanel5);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );

        jDesktopPane2.setLayer(jPanel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane2Layout = new javax.swing.GroupLayout(jDesktopPane2);
        jDesktopPane2.setLayout(jDesktopPane2Layout);
        jDesktopPane2Layout.setHorizontalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDesktopPane2Layout.setVerticalGroup(
            jDesktopPane2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jSplitPane2.setRightComponent(jDesktopPane2);

        jSplitPane1.setLeftComponent(jSplitPane2);

        jToolBar3.setRollover(true);

        jButtonJSNew.setText("New");
        jButtonJSNew.setFocusable(false);
        jButtonJSNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSNew.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSNewActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSNew);

        jButtonJSOpen.setText("Open");
        jButtonJSOpen.setFocusable(false);
        jButtonJSOpen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSOpen.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSOpenActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSOpen);

        jButtonJSSave.setText("Save");
        jButtonJSSave.setFocusable(false);
        jButtonJSSave.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSSave.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSSaveActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSSave);

        jButtonJSSaveAs.setText("Save As");
        jButtonJSSaveAs.setFocusable(false);
        jButtonJSSaveAs.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSSaveAs.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSSaveAsActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSSaveAs);

        jButtonJSClose.setText("Close");
        jButtonJSClose.setFocusable(false);
        jButtonJSClose.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSClose.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSCloseActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSClose);

        jPanel9.setPreferredSize(new java.awt.Dimension(20, 23));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 203, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );

        jToolBar3.add(jPanel9);

        jButtonJSUndo.setText("<");
        jButtonJSUndo.setFocusable(false);
        jButtonJSUndo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSUndo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSUndoActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSUndo);

        jButtonJSRedo.setText(">");
        jButtonJSRedo.setFocusable(false);
        jButtonJSRedo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonJSRedo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButtonJSRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonJSRedoActionPerformed(evt);
            }
        });
        jToolBar3.add(jButtonJSRedo);

        jLayeredPane5.setLayer(jToolBar3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane5Layout = new javax.swing.GroupLayout(jLayeredPane5);
        jLayeredPane5.setLayout(jLayeredPane5Layout);
        jLayeredPane5Layout.setHorizontalGroup(
            jLayeredPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar3, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );
        jLayeredPane5Layout.setVerticalGroup(
            jLayeredPane5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLayeredPane5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jToolBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane3.setViewportView(jTextArea3);

        jLayeredPane6.setLayer(jScrollPane3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane6Layout = new javax.swing.GroupLayout(jLayeredPane6);
        jLayeredPane6.setLayout(jLayeredPane6Layout);
        jLayeredPane6Layout.setHorizontalGroup(
            jLayeredPane6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3)
        );
        jLayeredPane6Layout.setVerticalGroup(
            jLayeredPane6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane5)
            .addComponent(jLayeredPane6, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLayeredPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane6))
        );

        jTabbedPane3.addTab("JavaScript", jPanel6);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        jDesktopPane3.setLayer(jPanel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane3Layout = new javax.swing.GroupLayout(jDesktopPane3);
        jDesktopPane3.setLayout(jDesktopPane3Layout);
        jDesktopPane3Layout.setHorizontalGroup(
            jDesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDesktopPane3Layout.setVerticalGroup(
            jDesktopPane3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jSplitPane1.setRightComponent(jDesktopPane3);

        jMenu1.setText("File");

        jMenu2.setText("Create New");

        jMenuItem5.setText("HTML");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem5);

        jMenuItem6.setText("CSS");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem6);

        jMenuItem7.setText("JavaScript");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem7);

        jMenu1.add(jMenu2);

        jMenu11.setText("Open");

        jMenuItem4.setText("HTML");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu11.add(jMenuItem4);

        jMenuItem8.setText("CSS");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu11.add(jMenuItem8);

        jMenuItem9.setText("JavaScript");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu11.add(jMenuItem9);

        jMenu1.add(jMenu11);

        jMenu12.setText("Save");

        jMenuItem10.setText("HTML");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu12.add(jMenuItem10);

        jMenuItem16.setText("CSS");
        jMenuItem16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem16ActionPerformed(evt);
            }
        });
        jMenu12.add(jMenuItem16);

        jMenuItem25.setText("JavaScript");
        jMenuItem25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem25ActionPerformed(evt);
            }
        });
        jMenu12.add(jMenuItem25);

        jMenu1.add(jMenu12);

        jMenu13.setText("Close");

        jMenuItem26.setText("HTML");
        jMenuItem26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem26ActionPerformed(evt);
            }
        });
        jMenu13.add(jMenuItem26);

        jMenuItem27.setText("CSS");
        jMenuItem27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem27ActionPerformed(evt);
            }
        });
        jMenu13.add(jMenuItem27);

        jMenuItem28.setText("JavaScript");
        jMenuItem28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem28ActionPerformed(evt);
            }
        });
        jMenu13.add(jMenuItem28);

        jMenu1.add(jMenu13);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("CodeGen");

        jMenu8.setText("HTML");

        jMenuItem1.setText("HTML Demo");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem1);

        jMenuItem2.setText("HTML Document");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem2);

        jMenuItem3.setText("HTML Heading");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem3);

        jMenuItem29.setText("HTML Paragraph");
        jMenuItem29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem29ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem29);

        jMenuItem30.setText("HTML Links");
        jMenuItem30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem30ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem30);

        jMenuItem31.setText("HTML Images");
        jMenuItem31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem31ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem31);

        jMenuItem32.setText("HTML Buttons");
        jMenuItem32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem32ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem32);

        jMenuItem33.setText("HTML Lists");
        jMenuItem33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem33ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem33);

        jMenuItem34.setText("HTML Iframes");
        jMenuItem34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem34ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem34);

        jMenuItem35.setText("HTML Styles");
        jMenuItem35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem35ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem35);

        jMenuItem50.setText("HTML Background Color");
        jMenuItem50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem50ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem50);

        jMenuItem51.setText("HTML Text Color");
        jMenuItem51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem51ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem51);

        jMenuItem52.setText("HTML Text Font");
        jMenuItem52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem52ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem52);

        jMenuItem53.setText("HTML Text Size");
        jMenuItem53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem53ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem53);

        jMenuItem54.setText("HTML Text Alignment");
        jMenuItem54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem54ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem54);

        jMenu3.add(jMenu8);

        jMenu9.setText("CSS");

        jMenuItem36.setText("CSS Template using Float");
        jMenuItem36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem36ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem36);

        jMenuItem37.setText("CSS Template using Flexbox");
        jMenuItem37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem37ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem37);

        jMenuItem38.setText("CSS Template using Grid");
        jMenuItem38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem38ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem38);

        jMenuItem39.setText("Topnav Content Footer");
        jMenuItem39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem39ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem39);

        jMenuItem40.setText("Sidenav Content");
        jMenuItem40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem40ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem40);

        jMenuItem47.setText("W3.CSS");
        jMenuItem47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem47ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem47);

        jMenuItem48.setText("Active Tab");
        jMenuItem48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem48ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem48);

        jMenuItem49.setText("Vertical Tabs");
        jMenuItem49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem49ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem49);

        jMenuItem55.setText("Animated Tab Content");
        jMenuItem55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem55ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem55);

        jMenuItem56.setText("Tabbed Image Gallery");
        jMenuItem56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem56ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem56);

        jMenuItem57.setText("Tabs in a Grid");
        jMenuItem57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem57ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem57);

        jMenuItem58.setText("Full Page Tabs");
        jMenuItem58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem58ActionPerformed(evt);
            }
        });
        jMenu9.add(jMenuItem58);

        jMenu3.add(jMenu9);

        jMenu10.setText("JavaScript");

        jMenuItem41.setText("Slideshows 1");
        jMenuItem41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem41ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem41);

        jMenuItem42.setText("Slideshows 2");
        jMenuItem42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem42ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem42);

        jMenuItem43.setText("Slideshows 3");
        jMenuItem43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem43ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem43);

        jMenuItem44.setText("W3.JS");
        jMenuItem44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem44ActionPerformed(evt);
            }
        });
        jMenu10.add(jMenuItem44);

        jMenu3.add(jMenu10);

        jMenu4.setText("Project Templates");

        jMenuItem11.setText("Band Template");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem11);

        jMenuItem13.setText("Cafe Template");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem13);

        jMenuItem12.setText("Gourmet Catering Template");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem12);

        jMenuItem45.setText("Wedding Invitation Template");
        jMenuItem45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem45ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem45);

        jMenuItem46.setText("Interior Design Template");
        jMenuItem46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem46ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem46);

        jMenu3.add(jMenu4);

        jMenuBar1.add(jMenu3);

        jMenu5.setText("Settings");

        jMenu6.setText("Style");

        jMenuItemA.setText("White & Black");
        jMenuItemA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItemA);

        jMenuItemB.setText("Black & White");
        jMenuItemB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemBActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItemB);

        jMenuItemC.setText("Black & Green");
        jMenuItemC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItemC);

        jMenuItemD.setText("Black & Orange");
        jMenuItemD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemDActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItemD);

        jMenu5.add(jMenu6);

        jMenu7.setText("Font Size");

        jMenuItem17.setText("14");
        jMenuItem17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem17ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem17);

        jMenuItem18.setText("16");
        jMenuItem18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem18ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem18);

        jMenuItem19.setText("18");
        jMenuItem19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem19ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem19);

        jMenuItem20.setText("20");
        jMenuItem20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem20ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem20);

        jMenuItem21.setText("22");
        jMenuItem21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem21ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem21);

        jMenuItem22.setText("24");
        jMenuItem22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem22ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem22);

        jMenuItem23.setText("26");
        jMenuItem23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem23ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem23);

        jMenuItem24.setText("28");
        jMenuItem24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem24ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem24);

        jMenuItem14.setText("30");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem14);

        jMenuItem15.setText("32");
        jMenuItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem15ActionPerformed(evt);
            }
        });
        jMenu7.add(jMenuItem15);

        jMenu5.add(jMenu7);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jSplitPane1)
                .addGap(1, 1, 1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonHTMLNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLNewActionPerformed
        // TODO add your handling code here:
        NewHTML();
    }//GEN-LAST:event_jButtonHTMLNewActionPerformed

    private void jButtonCSSNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSNewActionPerformed
        // TODO add your handling code here:
        NewCSS();
    }//GEN-LAST:event_jButtonCSSNewActionPerformed

    private void jButtonJSNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSNewActionPerformed
        // TODO add your handling code here:
        NewJS();
    }//GEN-LAST:event_jButtonJSNewActionPerformed

    private void jButtonHTMLOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLOpenActionPerformed
        // TODO add your handling code here:
        OpenHTML();
    }//GEN-LAST:event_jButtonHTMLOpenActionPerformed

    private void jButtonCSSOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSOpenActionPerformed
        // TODO add your handling code here:
        OpenCSS();
    }//GEN-LAST:event_jButtonCSSOpenActionPerformed

    private void jButtonJSOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSOpenActionPerformed
        // TODO add your handling code here:
        OpenJS();
    }//GEN-LAST:event_jButtonJSOpenActionPerformed

    private void jButtonHTMLSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLSaveActionPerformed
        // TODO add your handling code here:
        SaveHTML();
    }//GEN-LAST:event_jButtonHTMLSaveActionPerformed

    private void jButtonCSSSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSSaveActionPerformed
        // TODO add your handling code here:
        SaveCSS();
    }//GEN-LAST:event_jButtonCSSSaveActionPerformed

    private void jButtonJSSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSSaveActionPerformed
        // TODO add your handling code here:
        SaveJS();
    }//GEN-LAST:event_jButtonJSSaveActionPerformed

    private void jButtonHTMLSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLSaveAsActionPerformed
        // TODO add your handling code here:
        SaveAsHTML();
    }//GEN-LAST:event_jButtonHTMLSaveAsActionPerformed

    private void jButtonCSSSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSSaveAsActionPerformed
        // TODO add your handling code here:
        SaveAsCSS();
    }//GEN-LAST:event_jButtonCSSSaveAsActionPerformed

    private void jButtonJSSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSSaveAsActionPerformed
        // TODO add your handling code here:
        SaveAsJS();
    }//GEN-LAST:event_jButtonJSSaveAsActionPerformed

    private void jButtonHTMLCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLCloseActionPerformed
        // TODO add your handling code here:
        CloseHTML();
    }//GEN-LAST:event_jButtonHTMLCloseActionPerformed

    private void jButtonCSSCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSCloseActionPerformed
        // TODO add your handling code here:
        CloseCSS();
    }//GEN-LAST:event_jButtonCSSCloseActionPerformed

    private void jButtonJSCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSCloseActionPerformed
        // TODO add your handling code here:
        CloseJS();
    }//GEN-LAST:event_jButtonJSCloseActionPerformed

    private void jButtonHTMLUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLUndoActionPerformed
        // TODO add your handling code here:
        Undo1();
    }//GEN-LAST:event_jButtonHTMLUndoActionPerformed

    private void jButtonCSSUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSUndoActionPerformed
        // TODO add your handling code here:
        Undo2();
    }//GEN-LAST:event_jButtonCSSUndoActionPerformed

    private void jButtonJSUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSUndoActionPerformed
        // TODO add your handling code here:
        Undo3();
    }//GEN-LAST:event_jButtonJSUndoActionPerformed

    private void jButtonHTMLRedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHTMLRedoActionPerformed
        // TODO add your handling code here:
        Redo1();
    }//GEN-LAST:event_jButtonHTMLRedoActionPerformed

    private void jButtonCSSRedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCSSRedoActionPerformed
        // TODO add your handling code here:
        Redo2();
    }//GEN-LAST:event_jButtonCSSRedoActionPerformed

    private void jButtonJSRedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonJSRedoActionPerformed
        // TODO add your handling code here:
        Redo3();
    }//GEN-LAST:event_jButtonJSRedoActionPerformed

    private void jMenuItem17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem17ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font1);
        jTextArea2.setFont(font1);
        jTextArea3.setFont(font1);
        LineFont1();
    }//GEN-LAST:event_jMenuItem17ActionPerformed

    private void jMenuItem18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem18ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font2);
        jTextArea2.setFont(font2);
        jTextArea3.setFont(font2);
        LineFont2();
    }//GEN-LAST:event_jMenuItem18ActionPerformed

    private void jMenuItem19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem19ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font3);
        jTextArea2.setFont(font3);
        jTextArea3.setFont(font3);
        LineFont3();
    }//GEN-LAST:event_jMenuItem19ActionPerformed

    private void jMenuItem20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem20ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font4);
        jTextArea2.setFont(font4);
        jTextArea3.setFont(font4);
        LineFont4();
    }//GEN-LAST:event_jMenuItem20ActionPerformed

    private void jMenuItem21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem21ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font5);
        jTextArea2.setFont(font5);
        jTextArea3.setFont(font5);
        LineFont5();
    }//GEN-LAST:event_jMenuItem21ActionPerformed

    private void jMenuItem22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem22ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font6);
        jTextArea2.setFont(font6);
        jTextArea3.setFont(font6);
        LineFont6();
    }//GEN-LAST:event_jMenuItem22ActionPerformed

    private void jMenuItem23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem23ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font7);
        jTextArea2.setFont(font7);
        jTextArea3.setFont(font7);
        LineFont7();
    }//GEN-LAST:event_jMenuItem23ActionPerformed

    private void jMenuItem24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem24ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font8);
        jTextArea2.setFont(font8);
        jTextArea3.setFont(font8);
        LineFont8();
    }//GEN-LAST:event_jMenuItem24ActionPerformed

    private void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem14ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font9);
        jTextArea2.setFont(font9);
        jTextArea3.setFont(font9);
        LineFont9();
    }//GEN-LAST:event_jMenuItem14ActionPerformed

    private void jMenuItem15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem15ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setFont(font10);
        jTextArea2.setFont(font10);
        jTextArea3.setFont(font10);
        LineFont10();
    }//GEN-LAST:event_jMenuItem15ActionPerformed

    private void jMenuItemAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAActionPerformed
        // TODO add your handling code here:
        jTextArea1.setForeground(Color.BLACK);
        jTextArea1.setBackground(Color.WHITE);
        jTextArea2.setForeground(Color.BLACK);
        jTextArea2.setBackground(Color.WHITE);
        jTextArea3.setForeground(Color.BLACK);
        jTextArea3.setBackground(Color.WHITE);
    }//GEN-LAST:event_jMenuItemAActionPerformed

    private void jMenuItemBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemBActionPerformed
        // TODO add your handling code here:
        jTextArea1.setForeground(Color.WHITE);
        jTextArea1.setBackground(Color.BLACK);
        jTextArea2.setForeground(Color.WHITE);
        jTextArea2.setBackground(Color.BLACK);
        jTextArea3.setForeground(Color.WHITE);
        jTextArea3.setBackground(Color.BLACK);        
    }//GEN-LAST:event_jMenuItemBActionPerformed

    private void jMenuItemCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCActionPerformed
        // TODO add your handling code here:
        jTextArea1.setForeground(Color.GREEN);
        jTextArea1.setBackground(Color.BLACK);
        jTextArea2.setForeground(Color.GREEN);
        jTextArea2.setBackground(Color.BLACK);
        jTextArea3.setForeground(Color.GREEN);
        jTextArea3.setBackground(Color.BLACK);  
    }//GEN-LAST:event_jMenuItemCActionPerformed

    private void jMenuItemDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemDActionPerformed
        // TODO add your handling code here:
        jTextArea1.setForeground(Color.ORANGE);
        jTextArea1.setBackground(Color.BLACK);
        jTextArea2.setForeground(Color.ORANGE);
        jTextArea2.setBackground(Color.BLACK);
        jTextArea3.setForeground(Color.ORANGE);
        jTextArea3.setBackground(Color.BLACK); 
    }//GEN-LAST:event_jMenuItemDActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        // TODO add your handling code here:
        NewJS();
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        NewCSS();
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        NewHTML();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
        OpenHTML();
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
        OpenCSS();
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        // TODO add your handling code here:
        OpenJS();
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
        SaveHTML();
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem16ActionPerformed
        // TODO add your handling code here:
        SaveCSS();
    }//GEN-LAST:event_jMenuItem16ActionPerformed

    private void jMenuItem25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem25ActionPerformed
        // TODO add your handling code here:
        SaveJS();
    }//GEN-LAST:event_jMenuItem25ActionPerformed

    private void jMenuItem26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem26ActionPerformed
        // TODO add your handling code here:
        CloseHTML();
    }//GEN-LAST:event_jMenuItem26ActionPerformed

    private void jMenuItem27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem27ActionPerformed
        // TODO add your handling code here:
        CloseCSS();
    }//GEN-LAST:event_jMenuItem27ActionPerformed

    private void jMenuItem28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem28ActionPerformed
        // TODO add your handling code here:
        CloseJS();
    }//GEN-LAST:event_jMenuItem28ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<title>Page Title</title>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<h1>This is a Heading</h1>\n" +
"<p>This is a paragraph.</p>\n" +
"\n" +
"</body>\n" +
"</html> ");
        transferHTML();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1>My First Heading</h1>\n" +
"\n" +
"<p>My first paragraph.</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1>This is heading 1</h1>\n" +
"<h2>This is heading 2</h2>\n" +
"<h3>This is heading 3</h3>\n" +
"<h4>This is heading 4</h4>\n" +
"<h5>This is heading 5</h5>\n" +
"<h6>This is heading 6</h6>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem29ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<p>This is a paragraph.</p>\n" +
"<p>This is another paragraph.</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem29ActionPerformed

    private void jMenuItem30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem30ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<a href=\"https://www.w3schools.com\">This is a link</a>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem30ActionPerformed

    private void jMenuItem31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem31ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<img src=\"https://www.w3schools.com/html/w3schools.jpg\" alt=\"W3Schools.com\" width=\"104\" height=\"142\">");
        transferHTML();
    }//GEN-LAST:event_jMenuItem31ActionPerformed

    private void jMenuItem32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem32ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<button>Click me</button>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem32ActionPerformed

    private void jMenuItem33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem33ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h2>An Unordered HTML List</h2>\n" +
"\n" +
"<ul>\n" +
"  <li>Coffee</li>\n" +
"  <li>Tea</li>\n" +
"  <li>Milk</li>\n" +
"</ul>  \n" +
"\n" +
"<h2>An Ordered HTML List</h2>\n" +
"\n" +
"<ol>\n" +
"  <li>Coffee</li>\n" +
"  <li>Tea</li>\n" +
"  <li>Milk</li>\n" +
"</ol> ");
        transferHTML();
    }//GEN-LAST:event_jMenuItem33ActionPerformed

    private void jMenuItem34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem34ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<p>An iframe with default borders:</p>\n" +
"<iframe src=\"https://www.w3schools.com/\" width=\"100%\" height=\"300\">\n" +
"</iframe>\n" +
"\n" +
"<p>An iframe with a thin black border:</p>\n" +
"<iframe src=\"https://www.w3schools.com/\" width=\"100%\" height=\"300\" style=\"border:1px solid black;\">\n" +
"</iframe>\n" +
"\n" +
"<p>An iframe with no borders:</p>\n" +
"<iframe src=\"https://www.w3schools.com/\" width=\"100%\" height=\"300\" style=\"border:none;\">\n" +
"</iframe>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem34ActionPerformed

    private void jMenuItem35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem35ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<p style=\"color:red;\">I am red</p>\n" +
"<p style=\"color:blue;\">I am blue</p>\n" +
"<p style=\"font-size:50px;\">I am big</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem35ActionPerformed

    private void jMenuItem50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem50ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<body style=\"background-color:powderblue;\">\n" +
"\n" +
"<h1>This is a heading</h1>\n" +
"<p>This is a paragraph.</p>\n" +
"\n" +
"</body>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem50ActionPerformed

    private void jMenuItem51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem51ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1 style=\"color:blue;\">This is a heading</h1>\n" +
"<p style=\"color:red;\">This is a paragraph.</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem51ActionPerformed

    private void jMenuItem52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem52ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1 style=\"font-family:verdana;\">This is a heading</h1>\n" +
"<p style=\"font-family:courier;\">This is a paragraph.</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem52ActionPerformed

    private void jMenuItem53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem53ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1 style=\"font-size:300%;\">This is a heading</h1>\n" +
"<p style=\"font-size:160%;\">This is a paragraph.</p>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem53ActionPerformed

    private void jMenuItem54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem54ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<h1 style=\"text-align:left;\">Left Heading</h1>\n" +
"<h1 style=\"text-align:center;\">Centered Heading</h1>\n" +
"<h1 style=\"text-align:right;\">Right Heading</h1>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem54ActionPerformed

    private void jMenuItem36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem36ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<head>\n" +
"<title>CSS Template</title>\n" +
"<meta charset=\"utf-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<style>\n" +
"* {\n" +
"  box-sizing: border-box;\n" +
"}\n" +
"\n" +
"body {\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"/* Style the header */\n" +
".header {\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 30px;\n" +
"  text-align: center;\n" +
"  font-size: 35px;\n" +
"}\n" +
"\n" +
"/* Create three unequal columns that floats next to each other */\n" +
".column {\n" +
"  float: left;\n" +
"  padding: 10px;\n" +
"  height: 300px; /* Should be removed. Only for demonstration */\n" +
"}\n" +
"\n" +
"/* Left and right column */\n" +
".column.side {\n" +
"  width: 25%;\n" +
"}\n" +
"\n" +
"/* Middle column */\n" +
".column.middle {\n" +
"  width: 50%;\n" +
"}\n" +
"\n" +
"/* Clear floats after the columns */\n" +
".row:after {\n" +
"  content: \"\";\n" +
"  display: table;\n" +
"  clear: both;\n" +
"}\n" +
"\n" +
"/* Style the footer */\n" +
".footer {\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 10px;\n" +
"  text-align: center;\n" +
"}\n" +
"\n" +
"/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */\n" +
"@media (max-width: 600px) {\n" +
"  .column.side, .column.middle {\n" +
"    width: 100%;\n" +
"  }\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<h2>CSS Template using Float</h2>\n" +
"<p>In this example, we have created a header, three unequal columns and a footer. On smaller screens, the columns will stack on top of each other.</p>\n" +
"<p>Resize the browser window to see the responsive effect.</p>\n" +
"\n" +
"<div class=\"header\">\n" +
"  <h2>Header</h2>\n" +
"</div>\n" +
"\n" +
"<div class=\"row\">\n" +
"  <div class=\"column side\" style=\"background-color:#aaa;\">Column</div>\n" +
"  <div class=\"column middle\" style=\"background-color:#bbb;\">Column</div>\n" +
"  <div class=\"column side\" style=\"background-color:#ccc;\">Column</div>\n" +
"</div>\n" +
"\n" +
"<div class=\"footer\">\n" +
"  <p>Footer</p>\n" +
"</div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem36ActionPerformed

    private void jMenuItem37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem37ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<head>\n" +
"<title>CSS Template</title>\n" +
"<meta charset=\"utf-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<style>\n" +
"* {\n" +
"  box-sizing: border-box;\n" +
"}\n" +
"\n" +
"body {\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"/* Style the header */\n" +
".header {\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 30px;\n" +
"  text-align: center;\n" +
"  font-size: 35px;\n" +
"}\n" +
"\n" +
"/* Container for flexboxes */\n" +
".row {\n" +
"  display: -webkit-flex;\n" +
"  display: flex;\n" +
"}\n" +
"\n" +
"/* Create three unequal columns that sits next to each other */\n" +
".column {\n" +
"  padding: 10px;\n" +
"  height: 300px; /* Should be removed. Only for demonstration */\n" +
"}\n" +
"\n" +
"/* Left and right column */\n" +
".column.side {\n" +
"   -webkit-flex: 1;\n" +
"   -ms-flex: 1;\n" +
"   flex: 1;\n" +
"}\n" +
"\n" +
"/* Middle column */\n" +
".column.middle {\n" +
"  -webkit-flex: 2;\n" +
"  -ms-flex: 2;\n" +
"  flex: 2;\n" +
"}\n" +
"\n" +
"/* Style the footer */\n" +
".footer {\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 10px;\n" +
"  text-align: center;\n" +
"}\n" +
"\n" +
"/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */\n" +
"@media (max-width: 600px) {\n" +
"  .row {\n" +
"    -webkit-flex-direction: column;\n" +
"    flex-direction: column;\n" +
"  }\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<h2>CSS Template using Flexbox</h2>\n" +
"<p>In this example, we have created a header, three unequal columns and a footer. On smaller screens, the columns will stack on top of each other. Resize the browser window to see the responsive effect.</p>\n" +
"<p><strong>Note:</strong> Flexbox is not supported in Internet Explorer 10 and earlier versions.</p>\n" +
"\n" +
"<div class=\"header\">\n" +
"  <h2>Header</h2>\n" +
"</div>\n" +
"\n" +
"<div class=\"row\">\n" +
"  <div class=\"column side\" style=\"background-color:#aaa;\">Column</div>\n" +
"  <div class=\"column middle\" style=\"background-color:#bbb;\">Column</div>\n" +
"  <div class=\"column side\" style=\"background-color:#ccc;\">Column</div>\n" +
"</div>\n" +
"\n" +
"<div class=\"footer\">\n" +
"  <p>Footer</p>\n" +
"</div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem37ActionPerformed

    private void jMenuItem38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem38ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<style>\n" +
"* {\n" +
"  box-sizing: border-box;\n" +
"}\n" +
"\n" +
"body {\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"/* Style the header */\n" +
".header {\n" +
"  grid-area: header;\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 30px;\n" +
"  text-align: center;\n" +
"  font-size: 35px;\n" +
"}\n" +
"\n" +
"/* The grid container */\n" +
".grid-container {\n" +
"  display: grid;\n" +
"  grid-template-areas: \n" +
"    'header header header header header header' \n" +
"    'left middle middle middle middle right' \n" +
"    'footer footer footer footer footer footer';\n" +
"  /* grid-column-gap: 10px; - if you want gap between the columns */\n" +
"} \n" +
"\n" +
".left,\n" +
".middle,\n" +
".right {\n" +
"  padding: 10px;\n" +
"  height: 300px; /* Should be removed. Only for demonstration */\n" +
"}\n" +
"\n" +
"/* Style the left column */\n" +
".left {\n" +
"  grid-area: left;\n" +
"}\n" +
"\n" +
"/* Style the middle column */\n" +
".middle {\n" +
"  grid-area: middle;\n" +
"}\n" +
"\n" +
"/* Style the right column */\n" +
".right {\n" +
"  grid-area: right;\n" +
"}\n" +
"\n" +
"/* Style the footer */\n" +
".footer {\n" +
"  grid-area: footer;\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 10px;\n" +
"  text-align: center;\n" +
"}\n" +
"\n" +
"/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */\n" +
"@media (max-width: 600px) {\n" +
"  .grid-container  {\n" +
"    grid-template-areas: \n" +
"      'header header header header header header' \n" +
"      'left left left left left left' \n" +
"      'middle middle middle middle middle middle' \n" +
"      'right right right right right right' \n" +
"      'footer footer footer footer footer footer';\n" +
"  }\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<h2>CSS Template using Grid</h2>\n" +
"<p>In this example, we have created a header, three unequal columns and a footer. On smaller screens, the columns will stack on top of each other.</p>\n" +
"<p>Resize the browser window to see the responsive effect.</p>\n" +
"<p><strong>Note:</strong> The Grid Layout Module is not supported in Internet Explorer or Edge 15 eand earlier versions.</p>\n" +
"\n" +
"<div class=\"grid-container\">\n" +
"  <div class=\"header\">\n" +
"    <h2>Header</h2>\n" +
"  </div>\n" +
"  \n" +
"  <div class=\"left\" style=\"background-color:#aaa;\">Column</div>\n" +
"  <div class=\"middle\" style=\"background-color:#bbb;\">Column</div>  \n" +
"  <div class=\"right\" style=\"background-color:#ccc;\">Column</div>\n" +
"  \n" +
"  <div class=\"footer\">\n" +
"    <p>Footer</p>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem38ActionPerformed

    private void jMenuItem39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem39ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<head>\n" +
"<title>CSS Template</title>\n" +
"<meta charset=\"utf-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<style>\n" +
"* {\n" +
"  box-sizing: border-box;\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"body {\n" +
"  margin: 0;\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"/* Style the top navigation bar */\n" +
".topnav {\n" +
"  overflow: hidden;\n" +
"  background-color: #333;\n" +
"}\n" +
"\n" +
"/* Style the topnav links */\n" +
".topnav a {\n" +
"  float: left;\n" +
"  display: block;\n" +
"  color: #f2f2f2;\n" +
"  text-align: center;\n" +
"  padding: 14px 16px;\n" +
"  text-decoration: none;\n" +
"}\n" +
"\n" +
"/* Change color on hover */\n" +
".topnav a:hover {\n" +
"  background-color: #ddd;\n" +
"  color: black;\n" +
"}\n" +
"\n" +
"/* Style the content */\n" +
".content {\n" +
"  background-color: #ddd;\n" +
"  padding: 10px;\n" +
"  height: 200px; /* Should be removed. Only for demonstration */\n" +
"}\n" +
"\n" +
"/* Style the footer */\n" +
".footer {\n" +
"  background-color: #f1f1f1;\n" +
"  padding: 10px;\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<div class=\"topnav\">\n" +
"  <a href=\"#\">Link</a>\n" +
"  <a href=\"#\">Link</a>\n" +
"  <a href=\"#\">Link</a>\n" +
"</div>\n" +
"\n" +
"<div class=\"content\">\n" +
"  <h2>CSS Template</h2>\n" +
"  <p>A topnav, content and a footer.</p>\n" +
"</div>\n" +
"\n" +
"<div class=\"footer\">\n" +
"  <p>Footer</p>\n" +
"</div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem39ActionPerformed

    private void jMenuItem40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem40ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<head>\n" +
"<title>CSS Template</title>\n" +
"<meta charset=\"utf-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<style>\n" +
"* {\n" +
"  box-sizing: border-box;\n" +
"}\n" +
"\n" +
"body {\n" +
"  margin: 0;\n" +
"  font-family: Arial, Helvetica, sans-serif;\n" +
"}\n" +
"\n" +
"/* Style the side navigation */\n" +
".sidenav {\n" +
"  height: 100%;\n" +
"  width: 200px;\n" +
"  position: fixed;\n" +
"  z-index: 1;\n" +
"  top: 0;\n" +
"  left: 0;\n" +
"  background-color: #111;\n" +
"  overflow-x: hidden;\n" +
"}\n" +
"\n" +
"\n" +
"/* Side navigation links */\n" +
".sidenav a {\n" +
"  color: white;\n" +
"  padding: 16px;\n" +
"  text-decoration: none;\n" +
"  display: block;\n" +
"}\n" +
"\n" +
"/* Change color on hover */\n" +
".sidenav a:hover {\n" +
"  background-color: #ddd;\n" +
"  color: black;\n" +
"}\n" +
"\n" +
"/* Style the content */\n" +
".content {\n" +
"  margin-left: 200px;\n" +
"  padding-left: 20px;\n" +
"}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<div class=\"sidenav\">\n" +
"  <a href=\"#\">Link</a>\n" +
"  <a href=\"#\">Link</a>\n" +
"  <a href=\"#\">Link</a>\n" +
"</div>\n" +
"\n" +
"<div class=\"content\">\n" +
"  <h2>CSS Template</h2>\n" +
"  <p>A full-height, fixed sidenav and content.</p>\n" +
"</div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem40ActionPerformed

    private void jMenuItem41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem41ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.JS</title>\n" +
"<script src=\"https://www.w3schools.com/lib/w3.js\"></script>\n" +
"<body>\n" +
"\n" +
"<h2>Testing W3.JS in HTML</h2>\n" +
"\n" +
"<p>Elements with a class=\"city\" will behave like a slideshow:</p>\n" +
"\n" +
"<h1 class=\"city\">London</h1>\n" +
"<h1 class=\"city\">Paris</h1>\n" +
"<h1 class=\"city\">Tokyo</h1>\n" +
"\n" +
"<script>\n" +
"w3.slideshow(\".city\");\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferJS();
    }//GEN-LAST:event_jMenuItem41ActionPerformed

    private void jMenuItem42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem42ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.JS</title>\n" +
"<script src=\"https://www.w3schools.com/lib/w3.js\"></script>\n" +
"<body>\n" +
"\n" +
"<h2>Testing W3.JS in HTML</h2>\n" +
"\n" +
"<p>The slideshow is an object, with methods like next/previous:</p>\n" +
"\n" +
"<img class=\"nature\" src=\"img_snowtops.jpg\" width=\"50%\">\n" +
"<img class=\"nature\" src=\"img_mountains.jpg\" width=\"50%\">\n" +
"<img class=\"nature\" src=\"img_nature.jpg\" width=\"50%\">\n" +
"\n" +
"<p>\n" +
"<button onclick=\"myShow.previous()\">Previous</button>\n" +
"<button onclick=\"myShow.next()\">Next</button>\n" +
"</p>\n" +
"\n" +
"<script>\n" +
"myShow = w3.slideshow(\".nature\", 0);\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferJS();
    }//GEN-LAST:event_jMenuItem42ActionPerformed

    private void jMenuItem43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem43ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.JS</title>\n" +
"<script src=\"https://www.w3schools.com/lib/w3.js\"></script>\n" +
"<body>\n" +
"\n" +
"<h2>Testing W3.JS in HTML</h2>\n" +
"\n" +
"<p>Images with class=\"nature\" will be in the slideshow:</p>\n" +
"\n" +
"<img class=\"nature\" src=\"img_snowtops.jpg\" width=\"100%\">\n" +
"<img class=\"nature\" src=\"img_mountains.jpg\" width=\"100%\">\n" +
"<img class=\"nature\" src=\"img_nature.jpg\" width=\"100%\">\n" +
"\n" +
"<script>\n" +
"w3.slideshow(\".nature\", 1000);\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferJS();
    }//GEN-LAST:event_jMenuItem43ActionPerformed

    private void jMenuItem44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem44ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("/* W3.JS 1.04 April 2019 by w3schools.com */\n" +
"\"use strict\";\n" +
"var w3 = {};\n" +
"w3.hide = function (sel) {\n" +
"  w3.hideElements(w3.getElements(sel));\n" +
"};\n" +
"w3.hideElements = function (elements) {\n" +
"  var i, l = elements.length;\n" +
"  for (i = 0; i < l; i++) {\n" +
"    w3.hideElement(elements[i]);\n" +
"  }\n" +
"};\n" +
"w3.hideElement = function (element) {\n" +
"  w3.styleElement(element, \"display\", \"none\");\n" +
"};\n" +
"w3.show = function (sel, a) {\n" +
"  var elements = w3.getElements(sel);\n" +
"  if (a) {w3.hideElements(elements);}\n" +
"  w3.showElements(elements);\n" +
"};\n" +
"w3.showElements = function (elements) {\n" +
"  var i, l = elements.length;\n" +
"  for (i = 0; i < l; i++) {\n" +
"    w3.showElement(elements[i]);\n" +
"  }\n" +
"};\n" +
"w3.showElement = function (element) {\n" +
"  w3.styleElement(element, \"display\", \"block\");\n" +
"};\n" +
"w3.addStyle = function (sel, prop, val) {\n" +
"  w3.styleElements(w3.getElements(sel), prop, val);\n" +
"};\n" +
"w3.styleElements = function (elements, prop, val) {\n" +
"  var i, l = elements.length;\n" +
"  for (i = 0; i < l; i++) {    \n" +
"    w3.styleElement(elements[i], prop, val);\n" +
"  }\n" +
"};\n" +
"w3.styleElement = function (element, prop, val) {\n" +
"  element.style.setProperty(prop, val);\n" +
"};\n" +
"w3.toggleShow = function (sel) {\n" +
"  var i, x = w3.getElements(sel), l = x.length;\n" +
"  for (i = 0; i < l; i++) {    \n" +
"    if (x[i].style.display == \"none\") {\n" +
"      w3.styleElement(x[i], \"display\", \"block\");\n" +
"    } else {\n" +
"      w3.styleElement(x[i], \"display\", \"none\");\n" +
"    }\n" +
"  }\n" +
"};\n" +
"w3.addClass = function (sel, name) {\n" +
"  w3.addClassElements(w3.getElements(sel), name);\n" +
"};\n" +
"w3.addClassElements = function (elements, name) {\n" +
"  var i, l = elements.length;\n" +
"  for (i = 0; i < l; i++) {\n" +
"    w3.addClassElement(elements[i], name);\n" +
"  }\n" +
"};\n" +
"w3.addClassElement = function (element, name) {\n" +
"  var i, arr1, arr2;\n" +
"  arr1 = element.className.split(\" \");\n" +
"  arr2 = name.split(\" \");\n" +
"  for (i = 0; i < arr2.length; i++) {\n" +
"    if (arr1.indexOf(arr2[i]) == -1) {element.className += \" \" + arr2[i];}\n" +
"  }\n" +
"};\n" +
"w3.removeClass = function (sel, name) {\n" +
"  w3.removeClassElements(w3.getElements(sel), name);\n" +
"};\n" +
"w3.removeClassElements = function (elements, name) {\n" +
"  var i, l = elements.length, arr1, arr2, j;\n" +
"  for (i = 0; i < l; i++) {\n" +
"    w3.removeClassElement(elements[i], name);\n" +
"  }\n" +
"};\n" +
"w3.removeClassElement = function (element, name) {\n" +
"  var i, arr1, arr2;\n" +
"  arr1 = element.className.split(\" \");\n" +
"  arr2 = name.split(\" \");\n" +
"  for (i = 0; i < arr2.length; i++) {\n" +
"    while (arr1.indexOf(arr2[i]) > -1) {\n" +
"      arr1.splice(arr1.indexOf(arr2[i]), 1);     \n" +
"    }\n" +
"  }\n" +
"  element.className = arr1.join(\" \");\n" +
"};\n" +
"w3.toggleClass = function (sel, c1, c2) {\n" +
"  w3.toggleClassElements(w3.getElements(sel), c1, c2);\n" +
"};\n" +
"w3.toggleClassElements = function (elements, c1, c2) {\n" +
"  var i, l = elements.length;\n" +
"  for (i = 0; i < l; i++) {    \n" +
"    w3.toggleClassElement(elements[i], c1, c2);\n" +
"  }\n" +
"};\n" +
"w3.toggleClassElement = function (element, c1, c2) {\n" +
"  var t1, t2, t1Arr, t2Arr, j, arr, allPresent;\n" +
"  t1 = (c1 || \"\");\n" +
"  t2 = (c2 || \"\");\n" +
"  t1Arr = t1.split(\" \");\n" +
"  t2Arr = t2.split(\" \");\n" +
"  arr = element.className.split(\" \");\n" +
"  if (t2Arr.length == 0) {\n" +
"    allPresent = true;\n" +
"    for (j = 0; j < t1Arr.length; j++) {\n" +
"      if (arr.indexOf(t1Arr[j]) == -1) {allPresent = false;}\n" +
"    }\n" +
"    if (allPresent) {\n" +
"      w3.removeClassElement(element, t1);\n" +
"    } else {\n" +
"      w3.addClassElement(element, t1);\n" +
"    }\n" +
"  } else {\n" +
"    allPresent = true;\n" +
"    for (j = 0; j < t1Arr.length; j++) {\n" +
"      if (arr.indexOf(t1Arr[j]) == -1) {allPresent = false;}\n" +
"    }\n" +
"    if (allPresent) {\n" +
"      w3.removeClassElement(element, t1);\n" +
"      w3.addClassElement(element, t2);          \n" +
"    } else {\n" +
"      w3.removeClassElement(element, t2);        \n" +
"      w3.addClassElement(element, t1);\n" +
"    }\n" +
"  }\n" +
"};\n" +
"w3.getElements = function (id) {\n" +
"  if (typeof id == \"object\") {\n" +
"    return [id];\n" +
"  } else {\n" +
"    return document.querySelectorAll(id);\n" +
"  }\n" +
"};\n" +
"w3.filterHTML = function(id, sel, filter) {\n" +
"  var a, b, c, i, ii, iii, hit;\n" +
"  a = w3.getElements(id);\n" +
"  for (i = 0; i < a.length; i++) {\n" +
"    b = a[i].querySelectorAll(sel);\n" +
"    for (ii = 0; ii < b.length; ii++) {\n" +
"      hit = 0;\n" +
"      if (b[ii].innerText.toUpperCase().indexOf(filter.toUpperCase()) > -1) {\n" +
"        hit = 1;\n" +
"      }\n" +
"      c = b[ii].getElementsByTagName(\"*\");\n" +
"      for (iii = 0; iii < c.length; iii++) {\n" +
"        if (c[iii].innerText.toUpperCase().indexOf(filter.toUpperCase()) > -1) {\n" +
"          hit = 1;\n" +
"        }\n" +
"      }\n" +
"      if (hit == 1) {\n" +
"        b[ii].style.display = \"\";\n" +
"      } else {\n" +
"        b[ii].style.display = \"none\";\n" +
"      }\n" +
"    }\n" +
"  }\n" +
"};\n" +
"w3.sortHTML = function(id, sel, sortvalue) {\n" +
"  var a, b, i, ii, y, bytt, v1, v2, cc, j;\n" +
"  a = w3.getElements(id);\n" +
"  for (i = 0; i < a.length; i++) {\n" +
"    for (j = 0; j < 2; j++) {\n" +
"      cc = 0;\n" +
"      y = 1;\n" +
"      while (y == 1) {\n" +
"        y = 0;\n" +
"        b = a[i].querySelectorAll(sel);\n" +
"        for (ii = 0; ii < (b.length - 1); ii++) {\n" +
"          bytt = 0;\n" +
"          if (sortvalue) {\n" +
"            v1 = b[ii].querySelector(sortvalue).innerText;\n" +
"            v2 = b[ii + 1].querySelector(sortvalue).innerText;\n" +
"          } else {\n" +
"            v1 = b[ii].innerText;\n" +
"            v2 = b[ii + 1].innerText;\n" +
"          }\n" +
"          v1 = v1.toLowerCase();\n" +
"          v2 = v2.toLowerCase();\n" +
"          if ((j == 0 && (v1 > v2)) || (j == 1 && (v1 < v2))) {\n" +
"            bytt = 1;\n" +
"            break;\n" +
"          }\n" +
"        }\n" +
"        if (bytt == 1) {\n" +
"          b[ii].parentNode.insertBefore(b[ii + 1], b[ii]);\n" +
"          y = 1;\n" +
"          cc++;\n" +
"        }\n" +
"      }\n" +
"      if (cc > 0) {break;}\n" +
"    }\n" +
"  }\n" +
"};\n" +
"w3.slideshow = function (sel, ms, func) {\n" +
"  var i, ss, x = w3.getElements(sel), l = x.length;\n" +
"  ss = {};\n" +
"  ss.current = 1;\n" +
"  ss.x = x;\n" +
"  ss.ondisplaychange = func;\n" +
"  if (!isNaN(ms) || ms == 0) {\n" +
"    ss.milliseconds = ms;\n" +
"  } else {\n" +
"    ss.milliseconds = 1000;\n" +
"  }\n" +
"  ss.start = function() {\n" +
"    ss.display(ss.current)\n" +
"    if (ss.ondisplaychange) {ss.ondisplaychange();}\n" +
"    if (ss.milliseconds > 0) {\n" +
"      window.clearTimeout(ss.timeout);\n" +
"      ss.timeout = window.setTimeout(ss.next, ss.milliseconds);\n" +
"    }\n" +
"  };\n" +
"  ss.next = function() {\n" +
"    ss.current += 1;\n" +
"    if (ss.current > ss.x.length) {ss.current = 1;}\n" +
"    ss.start();\n" +
"  };\n" +
"  ss.previous = function() {\n" +
"    ss.current -= 1;\n" +
"    if (ss.current < 1) {ss.current = ss.x.length;}\n" +
"    ss.start();\n" +
"  };\n" +
"  ss.display = function (n) {\n" +
"    w3.styleElements(ss.x, \"display\", \"none\");\n" +
"    w3.styleElement(ss.x[n - 1], \"display\", \"block\");\n" +
"  }\n" +
"  ss.start();\n" +
"  return ss;\n" +
"};\n" +
"w3.includeHTML = function(cb) {\n" +
"  var z, i, elmnt, file, xhttp;\n" +
"  z = document.getElementsByTagName(\"*\");\n" +
"  for (i = 0; i < z.length; i++) {\n" +
"    elmnt = z[i];\n" +
"    file = elmnt.getAttribute(\"w3-include-html\");\n" +
"    if (file) {\n" +
"      xhttp = new XMLHttpRequest();\n" +
"      xhttp.onreadystatechange = function() {\n" +
"        if (this.readyState == 4) {\n" +
"          if (this.status == 200) {elmnt.innerHTML = this.responseText;}\n" +
"          if (this.status == 404) {elmnt.innerHTML = \"Page not found.\";}\n" +
"          elmnt.removeAttribute(\"w3-include-html\");\n" +
"          w3.includeHTML(cb);\n" +
"        }\n" +
"      }      \n" +
"      xhttp.open(\"GET\", file, true);\n" +
"      xhttp.send();\n" +
"      return;\n" +
"    }\n" +
"  }\n" +
"  if (cb) cb();\n" +
"};\n" +
"w3.getHttpData = function (file, func) {\n" +
"  w3.http(file, function () {\n" +
"    if (this.readyState == 4 && this.status == 200) {\n" +
"      func(this.responseText);\n" +
"    }\n" +
"  });\n" +
"};\n" +
"w3.getHttpObject = function (file, func) {\n" +
"  w3.http(file, function () {\n" +
"    if (this.readyState == 4 && this.status == 200) {\n" +
"      func(JSON.parse(this.responseText));\n" +
"    }\n" +
"  });\n" +
"};\n" +
"w3.displayHttp = function (id, file) {\n" +
"  w3.http(file, function () {\n" +
"    if (this.readyState == 4 && this.status == 200) {\n" +
"      w3.displayObject(id, JSON.parse(this.responseText));\n" +
"    }\n" +
"  });\n" +
"};\n" +
"w3.http = function (target, readyfunc, xml, method) {\n" +
"  var httpObj;\n" +
"  if (!method) {method = \"GET\"; }\n" +
"  if (window.XMLHttpRequest) {\n" +
"    httpObj = new XMLHttpRequest();\n" +
"  } else if (window.ActiveXObject) {\n" +
"    httpObj = new ActiveXObject(\"Microsoft.XMLHTTP\");\n" +
"  }\n" +
"  if (httpObj) {\n" +
"    if (readyfunc) {httpObj.onreadystatechange = readyfunc;}\n" +
"    httpObj.open(method, target, true);\n" +
"    httpObj.send(xml);\n" +
"  }\n" +
"};\n" +
"w3.getElementsByAttribute = function (x, att) {\n" +
"  var arr = [], arrCount = -1, i, l, y = x.getElementsByTagName(\"*\"), z = att.toUpperCase();\n" +
"  l = y.length;\n" +
"  for (i = -1; i < l; i += 1) {\n" +
"    if (i == -1) {y[i] = x;}\n" +
"    if (y[i].getAttribute(z) !== null) {arrCount += 1; arr[arrCount] = y[i];}\n" +
"  }\n" +
"  return arr;\n" +
"};  \n" +
"w3.dataObject = {},\n" +
"w3.displayObject = function (id, data) {\n" +
"  var htmlObj, htmlTemplate, html, arr = [], a, l, rowClone, x, j, i, ii, cc, repeat, repeatObj, repeatX = \"\";\n" +
"  htmlObj = document.getElementById(id);\n" +
"  htmlTemplate = init_template(id, htmlObj);\n" +
"  html = htmlTemplate.cloneNode(true);\n" +
"  arr = w3.getElementsByAttribute(html, \"w3-repeat\");\n" +
"  l = arr.length;\n" +
"  for (j = (l - 1); j >= 0; j -= 1) {\n" +
"    cc = arr[j].getAttribute(\"w3-repeat\").split(\" \");\n" +
"    if (cc.length == 1) {\n" +
"      repeat = cc[0];\n" +
"    } else {\n" +
"      repeatX = cc[0];\n" +
"      repeat = cc[2];\n" +
"    }\n" +
"    arr[j].removeAttribute(\"w3-repeat\");\n" +
"    repeatObj = data[repeat];\n" +
"    if (repeatObj && typeof repeatObj == \"object\" && repeatObj.length != \"undefined\") {\n" +
"      i = 0;\n" +
"      for (x in repeatObj) {\n" +
"        i += 1;\n" +
"        rowClone = arr[j];\n" +
"        rowClone = w3_replace_curly(rowClone, \"element\", repeatX, repeatObj[x]);\n" +
"        a = rowClone.attributes;\n" +
"        for (ii = 0; ii < a.length; ii += 1) {\n" +
"          a[ii].value = w3_replace_curly(a[ii], \"attribute\", repeatX, repeatObj[x]).value;\n" +
"        }\n" +
"        (i === repeatObj.length) ? arr[j].parentNode.replaceChild(rowClone, arr[j]) : arr[j].parentNode.insertBefore(rowClone, arr[j]);\n" +
"      }\n" +
"    } else {\n" +
"      console.log(\"w3-repeat must be an array. \" + repeat + \" is not an array.\");\n" +
"      continue;\n" +
"    }\n" +
"  }\n" +
"  html = w3_replace_curly(html, \"element\");\n" +
"  htmlObj.parentNode.replaceChild(html, htmlObj);\n" +
"  function init_template(id, obj) {\n" +
"    var template;\n" +
"    template = obj.cloneNode(true);\n" +
"    if (w3.dataObject.hasOwnProperty(id)) {return w3.dataObject[id];}\n" +
"    w3.dataObject[id] = template;\n" +
"    return template;\n" +
"  }\n" +
"  function w3_replace_curly(elmnt, typ, repeatX, x) {\n" +
"    var value, rowClone, pos1, pos2, originalHTML, lookFor, lookForARR = [], i, cc, r;\n" +
"    rowClone = elmnt.cloneNode(true);\n" +
"    pos1 = 0;\n" +
"    while (pos1 > -1) {\n" +
"      originalHTML = (typ == \"attribute\") ? rowClone.value : rowClone.innerHTML;\n" +
"      pos1 = originalHTML.indexOf(\"{{\", pos1);\n" +
"      if (pos1 === -1) {break;}\n" +
"      pos2 = originalHTML.indexOf(\"}}\", pos1 + 1);\n" +
"      lookFor = originalHTML.substring(pos1 + 2, pos2);\n" +
"      lookForARR = lookFor.split(\"||\");\n" +
"      value = undefined;\n" +
"      for (i = 0; i < lookForARR.length; i += 1) {\n" +
"        lookForARR[i] = lookForARR[i].replace(/^\\s+|\\s+$/gm, ''); //trim\n" +
"        if (x) {value = x[lookForARR[i]];}\n" +
"        if (value == undefined && data) {value = data[lookForARR[i]];}\n" +
"        if (value == undefined) {\n" +
"          cc = lookForARR[i].split(\".\");\n" +
"          if (cc[0] == repeatX) {value = x[cc[1]]; }\n" +
"        }\n" +
"        if (value == undefined) {\n" +
"          if (lookForARR[i] == repeatX) {value = x;}\n" +
"        }\n" +
"        if (value == undefined) {\n" +
"          if (lookForARR[i].substr(0, 1) == '\"') {\n" +
"            value = lookForARR[i].replace(/\"/g, \"\");\n" +
"          } else if (lookForARR[i].substr(0,1) == \"'\") {\n" +
"            value = lookForARR[i].replace(/'/g, \"\");\n" +
"          }\n" +
"        }\n" +
"        if (value != undefined) {break;}\n" +
"      }\n" +
"      if (value != undefined) {\n" +
"        r = \"{{\" + lookFor + \"}}\";\n" +
"        if (typ == \"attribute\") {\n" +
"          rowClone.value = rowClone.value.replace(r, value);\n" +
"        } else {\n" +
"          w3_replace_html(rowClone, r, value);\n" +
"        }\n" +
"      }\n" +
"      pos1 = pos1 + 1;\n" +
"    }\n" +
"    return rowClone;\n" +
"  }\n" +
"  function w3_replace_html(a, r, result) {\n" +
"    var b, l, i, a, x, j;\n" +
"    if (a.hasAttributes()) {\n" +
"      b = a.attributes;\n" +
"      l = b.length;\n" +
"      for (i = 0; i < l; i += 1) {\n" +
"        if (b[i].value.indexOf(r) > -1) {b[i].value = b[i].value.replace(r, result);}\n" +
"      }\n" +
"    }\n" +
"    x = a.getElementsByTagName(\"*\");\n" +
"    l = x.length;\n" +
"    a.innerHTML = a.innerHTML.replace(r, result);\n" +
"  }\n" +
"};");
        transferJS();
    }//GEN-LAST:event_jMenuItem44ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<title>W3.CSS Template</title>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Lato\">\n" +
"<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">\n" +
"<style>\n" +
"body {font-family: \"Lato\", sans-serif}\n" +
".mySlides {display: none}\n" +
"</style>\n" +
"<body>\n" +
"\n" +
"<!-- Navbar -->\n" +
"<div class=\"w3-top\">\n" +
"  <div class=\"w3-bar w3-black w3-card\">\n" +
"    <a class=\"w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right\" href=\"javascript:void(0)\" onclick=\"myFunction()\" title=\"Toggle Navigation Menu\"><i class=\"fa fa-bars\"></i></a>\n" +
"    <a href=\"#\" class=\"w3-bar-item w3-button w3-padding-large\">HOME</a>\n" +
"    <a href=\"#band\" class=\"w3-bar-item w3-button w3-padding-large w3-hide-small\">BAND</a>\n" +
"    <a href=\"#tour\" class=\"w3-bar-item w3-button w3-padding-large w3-hide-small\">TOUR</a>\n" +
"    <a href=\"#contact\" class=\"w3-bar-item w3-button w3-padding-large w3-hide-small\">CONTACT</a>\n" +
"    <div class=\"w3-dropdown-hover w3-hide-small\">\n" +
"      <button class=\"w3-padding-large w3-button\" title=\"More\">MORE <i class=\"fa fa-caret-down\"></i></button>     \n" +
"      <div class=\"w3-dropdown-content w3-bar-block w3-card-4\">\n" +
"        <a href=\"#\" class=\"w3-bar-item w3-button\">Merchandise</a>\n" +
"        <a href=\"#\" class=\"w3-bar-item w3-button\">Extras</a>\n" +
"        <a href=\"#\" class=\"w3-bar-item w3-button\">Media</a>\n" +
"      </div>\n" +
"    </div>\n" +
"    <a href=\"javascript:void(0)\" class=\"w3-padding-large w3-hover-red w3-hide-small w3-right\"><i class=\"fa fa-search\"></i></a>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->\n" +
"<div id=\"navDemo\" class=\"w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top\" style=\"margin-top:46px\">\n" +
"  <a href=\"#band\" class=\"w3-bar-item w3-button w3-padding-large\" onclick=\"myFunction()\">BAND</a>\n" +
"  <a href=\"#tour\" class=\"w3-bar-item w3-button w3-padding-large\" onclick=\"myFunction()\">TOUR</a>\n" +
"  <a href=\"#contact\" class=\"w3-bar-item w3-button w3-padding-large\" onclick=\"myFunction()\">CONTACT</a>\n" +
"  <a href=\"#\" class=\"w3-bar-item w3-button w3-padding-large\" onclick=\"myFunction()\">MERCH</a>\n" +
"</div>\n" +
"\n" +
"<!-- Page content -->\n" +
"<div class=\"w3-content\" style=\"max-width:2000px;margin-top:46px\">\n" +
"\n" +
"  <!-- Automatic Slideshow Images -->\n" +
"  <div class=\"mySlides w3-display-container w3-center\">\n" +
"    <img src=\"/w3images/la.jpg\" style=\"width:100%\">\n" +
"    <div class=\"w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small\">\n" +
"      <h3>Los Angeles</h3>\n" +
"      <p><b>We had the best time playing at Venice Beach!</b></p>   \n" +
"    </div>\n" +
"  </div>\n" +
"  <div class=\"mySlides w3-display-container w3-center\">\n" +
"    <img src=\"/w3images/ny.jpg\" style=\"width:100%\">\n" +
"    <div class=\"w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small\">\n" +
"      <h3>New York</h3>\n" +
"      <p><b>The atmosphere in New York is lorem ipsum.</b></p>    \n" +
"    </div>\n" +
"  </div>\n" +
"  <div class=\"mySlides w3-display-container w3-center\">\n" +
"    <img src=\"/w3images/chicago.jpg\" style=\"width:100%\">\n" +
"    <div class=\"w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small\">\n" +
"      <h3>Chicago</h3>\n" +
"      <p><b>Thank you, Chicago - A night we won't forget.</b></p>    \n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- The Band Section -->\n" +
"  <div class=\"w3-container w3-content w3-center w3-padding-64\" style=\"max-width:800px\" id=\"band\">\n" +
"    <h2 class=\"w3-wide\">THE BAND</h2>\n" +
"    <p class=\"w3-opacity\"><i>We love music</i></p>\n" +
"    <p class=\"w3-justify\">We have created a fictional band website. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip\n" +
"      ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur\n" +
"      adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>\n" +
"    <div class=\"w3-row w3-padding-32\">\n" +
"      <div class=\"w3-third\">\n" +
"        <p>Name</p>\n" +
"        <img src=\"/w3images/bandmember.jpg\" class=\"w3-round w3-margin-bottom\" alt=\"Random Name\" style=\"width:60%\">\n" +
"      </div>\n" +
"      <div class=\"w3-third\">\n" +
"        <p>Name</p>\n" +
"        <img src=\"/w3images/bandmember.jpg\" class=\"w3-round w3-margin-bottom\" alt=\"Random Name\" style=\"width:60%\">\n" +
"      </div>\n" +
"      <div class=\"w3-third\">\n" +
"        <p>Name</p>\n" +
"        <img src=\"/w3images/bandmember.jpg\" class=\"w3-round\" alt=\"Random Name\" style=\"width:60%\">\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- The Tour Section -->\n" +
"  <div class=\"w3-black\" id=\"tour\">\n" +
"    <div class=\"w3-container w3-content w3-padding-64\" style=\"max-width:800px\">\n" +
"      <h2 class=\"w3-wide w3-center\">TOUR DATES</h2>\n" +
"      <p class=\"w3-opacity w3-center\"><i>Remember to book your tickets!</i></p><br>\n" +
"\n" +
"      <ul class=\"w3-ul w3-border w3-white w3-text-grey\">\n" +
"        <li class=\"w3-padding\">September <span class=\"w3-tag w3-red w3-margin-left\">Sold out</span></li>\n" +
"        <li class=\"w3-padding\">October <span class=\"w3-tag w3-red w3-margin-left\">Sold out</span></li>\n" +
"        <li class=\"w3-padding\">November <span class=\"w3-badge w3-right w3-margin-right\">3</span></li>\n" +
"      </ul>\n" +
"\n" +
"      <div class=\"w3-row-padding w3-padding-32\" style=\"margin:0 -16px\">\n" +
"        <div class=\"w3-third w3-margin-bottom\">\n" +
"          <img src=\"/w3images/newyork.jpg\" alt=\"New York\" style=\"width:100%\" class=\"w3-hover-opacity\">\n" +
"          <div class=\"w3-container w3-white\">\n" +
"            <p><b>New York</b></p>\n" +
"            <p class=\"w3-opacity\">Fri 27 Nov 2016</p>\n" +
"            <p>Praesent tincidunt sed tellus ut rutrum sed vitae justo.</p>\n" +
"            <button class=\"w3-button w3-black w3-margin-bottom\" onclick=\"document.getElementById('ticketModal').style.display='block'\">Buy Tickets</button>\n" +
"          </div>\n" +
"        </div>\n" +
"        <div class=\"w3-third w3-margin-bottom\">\n" +
"          <img src=\"/w3images/paris.jpg\" alt=\"Paris\" style=\"width:100%\" class=\"w3-hover-opacity\">\n" +
"          <div class=\"w3-container w3-white\">\n" +
"            <p><b>Paris</b></p>\n" +
"            <p class=\"w3-opacity\">Sat 28 Nov 2016</p>\n" +
"            <p>Praesent tincidunt sed tellus ut rutrum sed vitae justo.</p>\n" +
"            <button class=\"w3-button w3-black w3-margin-bottom\" onclick=\"document.getElementById('ticketModal').style.display='block'\">Buy Tickets</button>\n" +
"          </div>\n" +
"        </div>\n" +
"        <div class=\"w3-third w3-margin-bottom\">\n" +
"          <img src=\"/w3images/sanfran.jpg\" alt=\"San Francisco\" style=\"width:100%\" class=\"w3-hover-opacity\">\n" +
"          <div class=\"w3-container w3-white\">\n" +
"            <p><b>San Francisco</b></p>\n" +
"            <p class=\"w3-opacity\">Sun 29 Nov 2016</p>\n" +
"            <p>Praesent tincidunt sed tellus ut rutrum sed vitae justo.</p>\n" +
"            <button class=\"w3-button w3-black w3-margin-bottom\" onclick=\"document.getElementById('ticketModal').style.display='block'\">Buy Tickets</button>\n" +
"          </div>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- Ticket Modal -->\n" +
"  <div id=\"ticketModal\" class=\"w3-modal\">\n" +
"    <div class=\"w3-modal-content w3-animate-top w3-card-4\">\n" +
"      <header class=\"w3-container w3-teal w3-center w3-padding-32\"> \n" +
"        <span onclick=\"document.getElementById('ticketModal').style.display='none'\" \n" +
"       class=\"w3-button w3-teal w3-xlarge w3-display-topright\">×</span>\n" +
"        <h2 class=\"w3-wide\"><i class=\"fa fa-suitcase w3-margin-right\"></i>Tickets</h2>\n" +
"      </header>\n" +
"      <div class=\"w3-container\">\n" +
"        <p><label><i class=\"fa fa-shopping-cart\"></i> Tickets, $15 per person</label></p>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"How many?\">\n" +
"        <p><label><i class=\"fa fa-user\"></i> Send To</label></p>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Enter email\">\n" +
"        <button class=\"w3-button w3-block w3-teal w3-padding-16 w3-section w3-right\">PAY <i class=\"fa fa-check\"></i></button>\n" +
"        <button class=\"w3-button w3-red w3-section\" onclick=\"document.getElementById('ticketModal').style.display='none'\">Close <i class=\"fa fa-remove\"></i></button>\n" +
"        <p class=\"w3-right\">Need <a href=\"#\" class=\"w3-text-blue\">help?</a></p>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- The Contact Section -->\n" +
"  <div class=\"w3-container w3-content w3-padding-64\" style=\"max-width:800px\" id=\"contact\">\n" +
"    <h2 class=\"w3-wide w3-center\">CONTACT</h2>\n" +
"    <p class=\"w3-opacity w3-center\"><i>Fan? Drop a note!</i></p>\n" +
"    <div class=\"w3-row w3-padding-32\">\n" +
"      <div class=\"w3-col m6 w3-large w3-margin-bottom\">\n" +
"        <i class=\"fa fa-map-marker\" style=\"width:30px\"></i> Chicago, US<br>\n" +
"        <i class=\"fa fa-phone\" style=\"width:30px\"></i> Phone: +00 151515<br>\n" +
"        <i class=\"fa fa-envelope\" style=\"width:30px\"> </i> Email: mail@mail.com<br>\n" +
"      </div>\n" +
"      <div class=\"w3-col m6\">\n" +
"        <form action=\"/action_page.php\" target=\"_blank\">\n" +
"          <div class=\"w3-row-padding\" style=\"margin:0 -16px 8px -16px\">\n" +
"            <div class=\"w3-half\">\n" +
"              <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Name\" required name=\"Name\">\n" +
"            </div>\n" +
"            <div class=\"w3-half\">\n" +
"              <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Email\" required name=\"Email\">\n" +
"            </div>\n" +
"          </div>\n" +
"          <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Message\" required name=\"Message\">\n" +
"          <button class=\"w3-button w3-black w3-section w3-right\" type=\"submit\">SEND</button>\n" +
"        </form>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"  \n" +
"<!-- End Page Content -->\n" +
"</div>\n" +
"\n" +
"<!-- Image of location/map -->\n" +
"<img src=\"/w3images/map.jpg\" class=\"w3-image w3-greyscale-min\" style=\"width:100%\">\n" +
"\n" +
"<!-- Footer -->\n" +
"<footer class=\"w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge\">\n" +
"  <i class=\"fa fa-facebook-official w3-hover-opacity\"></i>\n" +
"  <i class=\"fa fa-instagram w3-hover-opacity\"></i>\n" +
"  <i class=\"fa fa-snapchat w3-hover-opacity\"></i>\n" +
"  <i class=\"fa fa-pinterest-p w3-hover-opacity\"></i>\n" +
"  <i class=\"fa fa-twitter w3-hover-opacity\"></i>\n" +
"  <i class=\"fa fa-linkedin w3-hover-opacity\"></i>\n" +
"  <p class=\"w3-medium\">Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" target=\"_blank\">w3.css</a></p>\n" +
"</footer>\n" +
"\n" +
"<script>\n" +
"// Automatic Slideshow - change image every 4 seconds\n" +
"var myIndex = 0;\n" +
"carousel();\n" +
"\n" +
"function carousel() {\n" +
"  var i;\n" +
"  var x = document.getElementsByClassName(\"mySlides\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";  \n" +
"  }\n" +
"  myIndex++;\n" +
"  if (myIndex > x.length) {myIndex = 1}    \n" +
"  x[myIndex-1].style.display = \"block\";  \n" +
"  setTimeout(carousel, 4000);    \n" +
"}\n" +
"\n" +
"// Used to toggle the menu on small screens when clicking on the menu button\n" +
"function myFunction() {\n" +
"  var x = document.getElementById(\"navDemo\");\n" +
"  if (x.className.indexOf(\"w3-show\") == -1) {\n" +
"    x.className += \" w3-show\";\n" +
"  } else { \n" +
"    x.className = x.className.replace(\" w3-show\", \"\");\n" +
"  }\n" +
"}\n" +
"\n" +
"// When the user clicks anywhere outside of the modal, close it\n" +
"var modal = document.getElementById('ticketModal');\n" +
"window.onclick = function(event) {\n" +
"  if (event.target == modal) {\n" +
"    modal.style.display = \"none\";\n" +
"  }\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS Template</title>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Inconsolata\">\n" +
"<style>\n" +
"body, html {\n" +
"  height: 100%;\n" +
"  font-family: \"Inconsolata\", sans-serif;\n" +
"}\n" +
"\n" +
".bgimg {\n" +
"  background-position: center;\n" +
"  background-size: cover;\n" +
"  background-image: url(\"/w3images/coffeehouse.jpg\");\n" +
"  min-height: 75%;\n" +
"}\n" +
"\n" +
".menu {\n" +
"  display: none;\n" +
"}\n" +
"</style>\n" +
"<body>\n" +
"\n" +
"<!-- Links (sit on top) -->\n" +
"<div class=\"w3-top\">\n" +
"  <div class=\"w3-row w3-padding w3-black\">\n" +
"    <div class=\"w3-col s3\">\n" +
"      <a href=\"#\" class=\"w3-button w3-block w3-black\">HOME</a>\n" +
"    </div>\n" +
"    <div class=\"w3-col s3\">\n" +
"      <a href=\"#about\" class=\"w3-button w3-block w3-black\">ABOUT</a>\n" +
"    </div>\n" +
"    <div class=\"w3-col s3\">\n" +
"      <a href=\"#menu\" class=\"w3-button w3-block w3-black\">MENU</a>\n" +
"    </div>\n" +
"    <div class=\"w3-col s3\">\n" +
"      <a href=\"#where\" class=\"w3-button w3-block w3-black\">WHERE</a>\n" +
"    </div>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Header with image -->\n" +
"<header class=\"bgimg w3-display-container w3-grayscale-min\" id=\"home\">\n" +
"  <div class=\"w3-display-bottomleft w3-center w3-padding-large w3-hide-small\">\n" +
"    <span class=\"w3-tag\">Open from 6am to 5pm</span>\n" +
"  </div>\n" +
"  <div class=\"w3-display-middle w3-center\">\n" +
"    <span class=\"w3-text-white\" style=\"font-size:90px\">the<br>Cafe</span>\n" +
"  </div>\n" +
"  <div class=\"w3-display-bottomright w3-center w3-padding-large\">\n" +
"    <span class=\"w3-text-white\">15 Adr street, 5015</span>\n" +
"  </div>\n" +
"</header>\n" +
"\n" +
"<!-- Add a background color and large text to the whole page -->\n" +
"<div class=\"w3-sand w3-grayscale w3-large\">\n" +
"\n" +
"<!-- About Container -->\n" +
"<div class=\"w3-container\" id=\"about\">\n" +
"  <div class=\"w3-content\" style=\"max-width:700px\">\n" +
"    <h5 class=\"w3-center w3-padding-64\"><span class=\"w3-tag w3-wide\">ABOUT THE CAFE</span></h5>\n" +
"    <p>The Cafe was founded in blabla by Mr. Smith in lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>\n" +
"    <p>In addition to our full espresso and brew bar menu, we serve fresh made-to-order breakfast and lunch sandwiches, as well as a selection of sides and salads and other good stuff.</p>\n" +
"    <div class=\"w3-panel w3-leftbar w3-light-grey\">\n" +
"      <p><i>\"Use products from nature for what it's worth - but never too early, nor too late.\" Fresh is the new sweet.</i></p>\n" +
"      <p>Chef, Coffeeist and Owner: Liam Brown</p>\n" +
"    </div>\n" +
"    <img src=\"/w3images/coffeeshop.jpg\" style=\"width:100%;max-width:1000px\" class=\"w3-margin-top\">\n" +
"    <p><strong>Opening hours:</strong> everyday from 6am to 5pm.</p>\n" +
"    <p><strong>Address:</strong> 15 Adr street, 5015, NY</p>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Menu Container -->\n" +
"<div class=\"w3-container\" id=\"menu\">\n" +
"  <div class=\"w3-content\" style=\"max-width:700px\">\n" +
" \n" +
"    <h5 class=\"w3-center w3-padding-48\"><span class=\"w3-tag w3-wide\">THE MENU</span></h5>\n" +
"  \n" +
"    <div class=\"w3-row w3-center w3-card w3-padding\">\n" +
"      <a href=\"javascript:void(0)\" onclick=\"openMenu(event, 'Eat');\" id=\"myLink\">\n" +
"        <div class=\"w3-col s6 tablink\">Eat</div>\n" +
"      </a>\n" +
"      <a href=\"javascript:void(0)\" onclick=\"openMenu(event, 'Drinks');\">\n" +
"        <div class=\"w3-col s6 tablink\">Drink</div>\n" +
"      </a>\n" +
"    </div>\n" +
"\n" +
"    <div id=\"Eat\" class=\"w3-container menu w3-padding-48 w3-card\">\n" +
"      <h5>Bread Basket</h5>\n" +
"      <p class=\"w3-text-grey\">Assortment of fresh baked fruit breads and muffins 5.50</p><br>\n" +
"    \n" +
"      <h5>Honey Almond Granola with Fruits</h5>\n" +
"      <p class=\"w3-text-grey\">Natural cereal of honey toasted oats, raisins, almonds and dates 7.00</p><br>\n" +
"    \n" +
"      <h5>Belgian Waffle</h5>\n" +
"      <p class=\"w3-text-grey\">Vanilla flavored batter with malted flour 7.50</p><br>\n" +
"    \n" +
"      <h5>Scrambled eggs</h5>\n" +
"      <p class=\"w3-text-grey\">Scrambled eggs, roasted red pepper and garlic, with green onions 7.50</p><br>\n" +
"    \n" +
"      <h5>Blueberry Pancakes</h5>\n" +
"      <p class=\"w3-text-grey\">With syrup, butter and lots of berries 8.50</p>\n" +
"    </div>\n" +
"\n" +
"    <div id=\"Drinks\" class=\"w3-container menu w3-padding-48 w3-card\">\n" +
"      <h5>Coffee</h5>\n" +
"      <p class=\"w3-text-grey\">Regular coffee 2.50</p><br>\n" +
"    \n" +
"      <h5>Chocolato</h5>\n" +
"      <p class=\"w3-text-grey\">Chocolate espresso with milk 4.50</p><br>\n" +
"    \n" +
"      <h5>Corretto</h5>\n" +
"      <p class=\"w3-text-grey\">Whiskey and coffee 5.00</p><br>\n" +
"    \n" +
"      <h5>Iced tea</h5>\n" +
"      <p class=\"w3-text-grey\">Hot tea, except not hot 3.00</p><br>\n" +
"    \n" +
"      <h5>Soda</h5>\n" +
"      <p class=\"w3-text-grey\">Coke, Sprite, Fanta, etc. 2.50</p>\n" +
"    </div>  \n" +
"    <img src=\"/w3images/coffeehouse2.jpg\" style=\"width:100%;max-width:1000px;margin-top:32px;\">\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Contact/Area Container -->\n" +
"<div class=\"w3-container\" id=\"where\" style=\"padding-bottom:32px;\">\n" +
"  <div class=\"w3-content\" style=\"max-width:700px\">\n" +
"    <h5 class=\"w3-center w3-padding-48\"><span class=\"w3-tag w3-wide\">WHERE TO FIND US</span></h5>\n" +
"    <p>Find us at some address at some place.</p>\n" +
"    <img src=\"/w3images/map.jpg\" class=\"w3-image\" style=\"width:100%\">\n" +
"    <p><span class=\"w3-tag\">FYI!</span> We offer full-service catering for any event, large or small. We understand your needs and we will cater the food to satisfy the biggerst criteria of them all, both look and taste.</p>\n" +
"    <p><strong>Reserve</strong> a table, ask for today's special or just send us a message:</p>\n" +
"    <form action=\"/action_page.php\" target=\"_blank\">\n" +
"      <p><input class=\"w3-input w3-padding-16 w3-border\" type=\"text\" placeholder=\"Name\" required name=\"Name\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16 w3-border\" type=\"number\" placeholder=\"How many people\" required name=\"People\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16 w3-border\" type=\"datetime-local\" placeholder=\"Date and time\" required name=\"date\" value=\"2017-11-16T20:00\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16 w3-border\" type=\"text\" placeholder=\"Message \\ Special requirements\" required name=\"Message\"></p>\n" +
"      <p><button class=\"w3-button w3-black\" type=\"submit\">SEND MESSAGE</button></p>\n" +
"    </form>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- End page content -->\n" +
"</div>\n" +
"\n" +
"<!-- Footer -->\n" +
"<footer class=\"w3-center w3-light-grey w3-padding-48 w3-large\">\n" +
"  <p>Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" title=\"W3.CSS\" target=\"_blank\" class=\"w3-hover-text-green\">w3.css</a></p>\n" +
"</footer>\n" +
"\n" +
"<script>\n" +
"// Tabbed Menu\n" +
"function openMenu(evt, menuName) {\n" +
"  var i, x, tablinks;\n" +
"  x = document.getElementsByClassName(\"menu\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    tablinks[i].className = tablinks[i].className.replace(\" w3-dark-grey\", \"\");\n" +
"  }\n" +
"  document.getElementById(menuName).style.display = \"block\";\n" +
"  evt.currentTarget.firstElementChild.className += \" w3-dark-grey\";\n" +
"}\n" +
"document.getElementById(\"myLink\").click();\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS Template</title>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<style>\n" +
"body {font-family: \"Times New Roman\", Georgia, Serif;}\n" +
"h1, h2, h3, h4, h5, h6 {\n" +
"  font-family: \"Playfair Display\";\n" +
"  letter-spacing: 5px;\n" +
"}\n" +
"</style>\n" +
"<body>\n" +
"\n" +
"<!-- Navbar (sit on top) -->\n" +
"<div class=\"w3-top\">\n" +
"  <div class=\"w3-bar w3-white w3-padding w3-card\" style=\"letter-spacing:4px;\">\n" +
"    <a href=\"#home\" class=\"w3-bar-item w3-button\">Gourmet au Catering</a>\n" +
"    <!-- Right-sided navbar links. Hide them on small screens -->\n" +
"    <div class=\"w3-right w3-hide-small\">\n" +
"      <a href=\"#about\" class=\"w3-bar-item w3-button\">About</a>\n" +
"      <a href=\"#menu\" class=\"w3-bar-item w3-button\">Menu</a>\n" +
"      <a href=\"#contact\" class=\"w3-bar-item w3-button\">Contact</a>\n" +
"    </div>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Header -->\n" +
"<header class=\"w3-display-container w3-content w3-wide\" style=\"max-width:1600px;min-width:500px\" id=\"home\">\n" +
"  <img class=\"w3-image\" src=\"/w3images/hamburger.jpg\" alt=\"Hamburger Catering\" width=\"1600\" height=\"800\">\n" +
"  <div class=\"w3-display-bottomleft w3-padding-large w3-opacity\">\n" +
"    <h1 class=\"w3-xxlarge\">Le Catering</h1>\n" +
"  </div>\n" +
"</header>\n" +
"\n" +
"<!-- Page content -->\n" +
"<div class=\"w3-content\" style=\"max-width:1100px\">\n" +
"\n" +
"  <!-- About Section -->\n" +
"  <div class=\"w3-row w3-padding-64\" id=\"about\">\n" +
"    <div class=\"w3-col m6 w3-padding-large w3-hide-small\">\n" +
"     <img src=\"/w3images/tablesetting2.jpg\" class=\"w3-round w3-image w3-opacity-min\" alt=\"Table Setting\" width=\"600\" height=\"750\">\n" +
"    </div>\n" +
"\n" +
"    <div class=\"w3-col m6 w3-padding-large\">\n" +
"      <h1 class=\"w3-center\">About Catering</h1><br>\n" +
"      <h5 class=\"w3-center\">Tradition since 1889</h5>\n" +
"      <p class=\"w3-large\">The Catering was founded in blabla by Mr. Smith in lorem ipsum dolor sit amet, consectetur adipiscing elit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute iruredolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.We only use <span class=\"w3-tag w3-light-grey\">seasonal</span> ingredients.</p>\n" +
"      <p class=\"w3-large w3-text-grey w3-hide-medium\">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod temporincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>\n" +
"    </div>\n" +
"  </div>\n" +
"  \n" +
"  <hr>\n" +
"  \n" +
"  <!-- Menu Section -->\n" +
"  <div class=\"w3-row w3-padding-64\" id=\"menu\">\n" +
"    <div class=\"w3-col l6 w3-padding-large\">\n" +
"      <h1 class=\"w3-center\">Our Menu</h1><br>\n" +
"      <h4>Bread Basket</h4>\n" +
"      <p class=\"w3-text-grey\">Assortment of fresh baked fruit breads and muffins 5.50</p><br>\n" +
"    \n" +
"      <h4>Honey Almond Granola with Fruits</h4>\n" +
"      <p class=\"w3-text-grey\">Natural cereal of honey toasted oats, raisins, almonds and dates 7.00</p><br>\n" +
"    \n" +
"      <h4>Belgian Waffle</h4>\n" +
"      <p class=\"w3-text-grey\">Vanilla flavored batter with malted flour 7.50</p><br>\n" +
"    \n" +
"      <h4>Scrambled eggs</h4>\n" +
"      <p class=\"w3-text-grey\">Scrambled eggs, roasted red pepper and garlic, with green onions 7.50</p><br>\n" +
"    \n" +
"      <h4>Blueberry Pancakes</h4>\n" +
"      <p class=\"w3-text-grey\">With syrup, butter and lots of berries 8.50</p>    \n" +
"    </div>\n" +
"    \n" +
"    <div class=\"w3-col l6 w3-padding-large\">\n" +
"      <img src=\"/w3images/tablesetting.jpg\" class=\"w3-round w3-image w3-opacity-min\" alt=\"Menu\" style=\"width:100%\">\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <hr>\n" +
"\n" +
"  <!-- Contact Section -->\n" +
"  <div class=\"w3-container w3-padding-64\" id=\"contact\">\n" +
"    <h1>Contact</h1><br>\n" +
"    <p>We offer full-service catering for any event, large or small. We understand your needs and we will cater the food to satisfy the biggerst criteria of them all, both look and taste. Do not hesitate to contact us.</p>\n" +
"    <p class=\"w3-text-blue-grey w3-large\"><b>Catering Service, 42nd Living St, 43043 New York, NY</b></p>\n" +
"    <p>You can also contact us by phone 00553123-2323 or email catering@catering.com, or you can send us a message here:</p>\n" +
"    <form action=\"/action_page.php\" target=\"_blank\">\n" +
"      <p><input class=\"w3-input w3-padding-16\" type=\"text\" placeholder=\"Name\" required name=\"Name\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16\" type=\"number\" placeholder=\"How many people\" required name=\"People\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16\" type=\"datetime-local\" placeholder=\"Date and time\" required name=\"date\" value=\"2017-11-16T20:00\"></p>\n" +
"      <p><input class=\"w3-input w3-padding-16\" type=\"text\" placeholder=\"Message \\ Special requirements\" required name=\"Message\"></p>\n" +
"      <p><button class=\"w3-button w3-light-grey w3-section\" type=\"submit\">SEND MESSAGE</button></p>\n" +
"    </form>\n" +
"  </div>\n" +
"  \n" +
"<!-- End page content -->\n" +
"</div>\n" +
"\n" +
"<!-- Footer -->\n" +
"<footer class=\"w3-center w3-light-grey w3-padding-32\">\n" +
"  <p>Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" title=\"W3.CSS\" target=\"_blank\" class=\"w3-hover-text-green\">w3.css</a></p>\n" +
"</footer>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem45ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS Template</title>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Raleway\">\n" +
"<style>\n" +
"body,h1,h2{font-family: \"Raleway\", sans-serif}\n" +
"body, html {height: 100%}\n" +
"p {line-height: 2}\n" +
".bgimg, .bgimg2 {\n" +
"  min-height: 100%;\n" +
"  background-position: center;\n" +
"  background-size: cover;\n" +
"}\n" +
".bgimg {background-image: url(\"/w3images/wedding_couple.jpg\")}\n" +
".bgimg2 {background-image: url(\"/w3images/flowers.jpg\")}\n" +
"</style>\n" +
"<body>\n" +
"\n" +
"<!-- Header / Home-->\n" +
"<header class=\"w3-display-container w3-wide bgimg w3-grayscale-min\" id=\"home\">\n" +
"  <div class=\"w3-display-middle w3-text-white w3-center\">\n" +
"    <h1 class=\"w3-jumbo\">Jane & John</h1>\n" +
"    <h2>Are getting married</h2>\n" +
"    <h2><b>17.07.2017</b></h2>\n" +
"  </div>\n" +
"</header>\n" +
"\n" +
"<!-- Navbar (sticky bottom) -->\n" +
"<div class=\"w3-bottom w3-hide-small\">\n" +
"  <div class=\"w3-bar w3-white w3-center w3-padding w3-opacity-min w3-hover-opacity-off\">\n" +
"    <a href=\"#home\" style=\"width:25%\" class=\"w3-bar-item w3-button\">Home</a>\n" +
"    <a href=\"#us\" style=\"width:25%\" class=\"w3-bar-item w3-button\">Jane & John</a>\n" +
"    <a href=\"#wedding\" style=\"width:25%\" class=\"w3-bar-item w3-button\">Wedding</a>\n" +
"    <a href=\"#rsvp\" style=\"width:25%\" class=\"w3-bar-item w3-button w3-hover-black\">RSVP</a>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- About / Jane And John -->\n" +
"<div class=\"w3-container w3-padding-64 w3-pale-red w3-grayscale-min\" id=\"us\">\n" +
"  <div class=\"w3-content\">\n" +
"    <h1 class=\"w3-center w3-text-grey\"><b>Jane & John</b></h1>\n" +
"    <img class=\"w3-round w3-grayscale-min\" src=\"/w3images/wedding_couple2.jpg\" style=\"width:100%;margin:32px 0\">\n" +
"    <p><i>You all know us. And we all know you. We are getting married lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint\n" +
"      occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco\n" +
"      laboris nisi ut aliquip ex ea commodo consequat.</i>\n" +
"    </p><br>\n" +
"    <p class=\"w3-center\"><a href=\"#wedding\" class=\"w3-button w3-black w3-round w3-padding-large w3-large\">Wedding Details</a></p>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Background photo -->\n" +
"<div class=\"w3-display-container bgimg2\">\n" +
"  <div class=\"w3-display-middle w3-text-white w3-center\">\n" +
"    <h1 class=\"w3-jumbo\">You Are Invited</h1><br>\n" +
"    <h2>Of course..</h2>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Wedding information -->\n" +
"<div class=\"w3-container w3-padding-64 w3-pale-red w3-grayscale-min w3-center\" id=\"wedding\">\n" +
"  <div class=\"w3-content\">\n" +
"    <h1 class=\"w3-text-grey\"><b>THE WEDDING</b></h1>\n" +
"    <img class=\"w3-round-large w3-grayscale-min\" src=\"/w3images/wedding_location.jpg\" style=\"width:100%;margin:64px 0\">\n" +
"    <div class=\"w3-row\">\n" +
"      <div class=\"w3-half\">\n" +
"        <h2>When</h2>\n" +
"        <p>Wedding Ceremony - 2:00pm</p>\n" +
"        <p>Reception & Dinner - 5:00pm</p>\n" +
"      </div>\n" +
"      <div class=\"w3-half\">\n" +
"        <h2>Where</h2>\n" +
"        <p>Some place, an address</p>\n" +
"        <p>Some where, some address</p>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- RSVP section -->\n" +
"<div class=\"w3-container w3-padding-64 w3-pale-red w3-center w3-wide\" id=\"rsvp\">\n" +
"  <h1>HOPE YOU CAN MAKE IT!</h1>\n" +
"  <p class=\"w3-large\">Kindly Respond By January, 2017</p>\n" +
"  <p class=\"w3-xlarge\">\n" +
"    <button onclick=\"document.getElementById('id01').style.display='block'\" class=\"w3-button w3-round w3-red w3-opacity w3-hover-opacity-off\" style=\"padding:8px 60px\">RSVP</button>\n" +
"  </p>\n" +
"</div>\n" +
"\n" +
"<!-- RSVP modal -->\n" +
"<div id=\"id01\" class=\"w3-modal\">\n" +
"  <div class=\"w3-modal-content w3-card-4 w3-animate-zoom\" style=\"padding:32px;max-width:600px\">\n" +
"    <div class=\"w3-container w3-white w3-center\">\n" +
"      <h1 class=\"w3-wide\">CAN YOU COME?</h1>\n" +
"      <p>We really hope you can make it.</p>\n" +
"      <form>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" placeholder=\"Name(s)\" name=\"name\">\n" +
"      </form>\n" +
"      <p><i>Sincerely, John & Jane</i></p>\n" +
"      <div class=\"w3-row\">\n" +
"        <div class=\"w3-half\">\n" +
"          <button onclick=\"document.getElementById('id01').style.display='none'\" type=\"button\" class=\"w3-button w3-block w3-green\">Going</button>\n" +
"        </div>\n" +
"        <div class=\"w3-half\">\n" +
"          <button onclick=\"document.getElementById('id01').style.display='none'\" type=\"button\" class=\"w3-button w3-block w3-red\">Can't come</button>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- Footer -->\n" +
"<footer class=\"w3-center w3-black w3-padding-16\">\n" +
"  <p>Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" title=\"W3.CSS\" target=\"_blank\" class=\"w3-hover-text-green\">w3.css</a></p>\n" +
"</footer>\n" +
"<div class=\"w3-hide-small\" style=\"margin-bottom:32px\"> </div>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem45ActionPerformed

    private void jMenuItem46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem46ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html lang=\"en\">\n" +
"<title>W3.CSS Template</title>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Poppins\">\n" +
"<style>\n" +
"body,h1,h2,h3,h4,h5 {font-family: \"Poppins\", sans-serif}\n" +
"body {font-size:16px;}\n" +
".w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}\n" +
".w3-half img:hover{opacity:1}\n" +
"</style>\n" +
"<body>\n" +
"\n" +
"<!-- Sidebar/menu -->\n" +
"<nav class=\"w3-sidebar w3-red w3-collapse w3-top w3-large w3-padding\" style=\"z-index:3;width:300px;font-weight:bold;\" id=\"mySidebar\"><br>\n" +
"  <a href=\"javascript:void(0)\" onclick=\"w3_close()\" class=\"w3-button w3-hide-large w3-display-topleft\" style=\"width:100%;font-size:22px\">Close Menu</a>\n" +
"  <div class=\"w3-container\">\n" +
"    <h3 class=\"w3-padding-64\"><b>Company<br>Name</b></h3>\n" +
"  </div>\n" +
"  <div class=\"w3-bar-block\">\n" +
"    <a href=\"#\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Home</a> \n" +
"    <a href=\"#showcase\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Showcase</a> \n" +
"    <a href=\"#services\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Services</a> \n" +
"    <a href=\"#designers\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Designers</a> \n" +
"    <a href=\"#packages\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Packages</a> \n" +
"    <a href=\"#contact\" onclick=\"w3_close()\" class=\"w3-bar-item w3-button w3-hover-white\">Contact</a>\n" +
"  </div>\n" +
"</nav>\n" +
"\n" +
"<!-- Top menu on small screens -->\n" +
"<header class=\"w3-container w3-top w3-hide-large w3-red w3-xlarge w3-padding\">\n" +
"  <a href=\"javascript:void(0)\" class=\"w3-button w3-red w3-margin-right\" onclick=\"w3_open()\">☰</a>\n" +
"  <span>Company Name</span>\n" +
"</header>\n" +
"\n" +
"<!-- Overlay effect when opening sidebar on small screens -->\n" +
"<div class=\"w3-overlay w3-hide-large\" onclick=\"w3_close()\" style=\"cursor:pointer\" title=\"close side menu\" id=\"myOverlay\"></div>\n" +
"\n" +
"<!-- !PAGE CONTENT! -->\n" +
"<div class=\"w3-main\" style=\"margin-left:340px;margin-right:40px\">\n" +
"\n" +
"  <!-- Header -->\n" +
"  <div class=\"w3-container\" style=\"margin-top:80px\" id=\"showcase\">\n" +
"    <h1 class=\"w3-jumbo\"><b>Interior Design</b></h1>\n" +
"    <h1 class=\"w3-xxxlarge w3-text-red\"><b>Showcase.</b></h1>\n" +
"    <hr style=\"width:50px;border:5px solid red\" class=\"w3-round\">\n" +
"  </div>\n" +
"  \n" +
"  <!-- Photo grid (modal) -->\n" +
"  <div class=\"w3-row-padding\">\n" +
"    <div class=\"w3-half\">\n" +
"      <img src=\"/w3images/kitchenconcrete.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"Concrete meets bricks\">\n" +
"      <img src=\"/w3images/livingroom.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"Light, white and tight scandinavian design\">\n" +
"      <img src=\"/w3images/diningroom.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"White walls with designer chairs\">\n" +
"    </div>\n" +
"\n" +
"    <div class=\"w3-half\">\n" +
"      <img src=\"/w3images/atrium.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"Windows for the atrium\">\n" +
"      <img src=\"/w3images/bedroom.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"Bedroom and office in one space\">\n" +
"      <img src=\"/w3images/livingroom2.jpg\" style=\"width:100%\" onclick=\"onClick(this)\" alt=\"Scandinavian design\">\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- Modal for full size images on click-->\n" +
"  <div id=\"modal01\" class=\"w3-modal w3-black\" style=\"padding-top:0\" onclick=\"this.style.display='none'\">\n" +
"    <span class=\"w3-button w3-black w3-xxlarge w3-display-topright\">×</span>\n" +
"    <div class=\"w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64\">\n" +
"      <img id=\"img01\" class=\"w3-image\">\n" +
"      <p id=\"caption\"></p>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- Services -->\n" +
"  <div class=\"w3-container\" id=\"services\" style=\"margin-top:75px\">\n" +
"    <h1 class=\"w3-xxxlarge w3-text-red\"><b>Services.</b></h1>\n" +
"    <hr style=\"width:50px;border:5px solid red\" class=\"w3-round\">\n" +
"    <p>We are a interior design service that focus on what's best for your home and what's best for you!</p>\n" +
"    <p>Some text about our services - what we do and what we offer. We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure\n" +
"    dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor\n" +
"    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n" +
"    </p>\n" +
"  </div>\n" +
"  \n" +
"  <!-- Designers -->\n" +
"  <div class=\"w3-container\" id=\"designers\" style=\"margin-top:75px\">\n" +
"    <h1 class=\"w3-xxxlarge w3-text-red\"><b>Designers.</b></h1>\n" +
"    <hr style=\"width:50px;border:5px solid red\" class=\"w3-round\">\n" +
"    <p>The best team in the world.</p>\n" +
"    <p>We are lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure\n" +
"    dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor\n" +
"    incididunt ut labore et quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n" +
"    </p>\n" +
"    <p><b>Our designers are thoughtfully chosen</b>:</p>\n" +
"  </div>\n" +
"\n" +
"  <!-- The Team -->\n" +
"  <div class=\"w3-row-padding w3-grayscale\">\n" +
"    <div class=\"w3-col m4 w3-margin-bottom\">\n" +
"      <div class=\"w3-light-grey\">\n" +
"        <img src=\"/w3images/team2.jpg\" alt=\"John\" style=\"width:100%\">\n" +
"        <div class=\"w3-container\">\n" +
"          <h3>John Doe</h3>\n" +
"          <p class=\"w3-opacity\">CEO & Founder</p>\n" +
"          <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"    <div class=\"w3-col m4 w3-margin-bottom\">\n" +
"      <div class=\"w3-light-grey\">\n" +
"        <img src=\"/w3images/team1.jpg\" alt=\"Jane\" style=\"width:100%\">\n" +
"        <div class=\"w3-container\">\n" +
"          <h3>Jane Doe</h3>\n" +
"          <p class=\"w3-opacity\">Designer</p>\n" +
"          <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"    <div class=\"w3-col m4 w3-margin-bottom\">\n" +
"      <div class=\"w3-light-grey\">\n" +
"        <img src=\"/w3images/team3.jpg\" alt=\"Mike\" style=\"width:100%\">\n" +
"        <div class=\"w3-container\">\n" +
"          <h3>Mike Ross</h3>\n" +
"          <p class=\"w3-opacity\">Architect</p>\n" +
"          <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <!-- Packages / Pricing Tables -->\n" +
"  <div class=\"w3-container\" id=\"packages\" style=\"margin-top:75px\">\n" +
"    <h1 class=\"w3-xxxlarge w3-text-red\"><b>Packages.</b></h1>\n" +
"    <hr style=\"width:50px;border:5px solid red\" class=\"w3-round\">\n" +
"    <p>Some text our prices. Lorem ipsum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure</p>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"w3-row-padding\">\n" +
"    <div class=\"w3-half w3-margin-bottom\">\n" +
"      <ul class=\"w3-ul w3-light-grey w3-center\">\n" +
"        <li class=\"w3-dark-grey w3-xlarge w3-padding-32\">Basic</li>\n" +
"        <li class=\"w3-padding-16\">Floorplanning</li>\n" +
"        <li class=\"w3-padding-16\">10 hours support</li>\n" +
"        <li class=\"w3-padding-16\">Photography</li>\n" +
"        <li class=\"w3-padding-16\">20% furniture discount</li>\n" +
"        <li class=\"w3-padding-16\">Good deals</li>\n" +
"        <li class=\"w3-padding-16\">\n" +
"          <h2>$ 199</h2>\n" +
"          <span class=\"w3-opacity\">per room</span>\n" +
"        </li>\n" +
"        <li class=\"w3-light-grey w3-padding-24\">\n" +
"          <button class=\"w3-button w3-white w3-padding-large w3-hover-black\">Sign Up</button>\n" +
"        </li>\n" +
"      </ul>\n" +
"    </div>\n" +
"        \n" +
"    <div class=\"w3-half\">\n" +
"      <ul class=\"w3-ul w3-light-grey w3-center\">\n" +
"        <li class=\"w3-red w3-xlarge w3-padding-32\">Pro</li>\n" +
"        <li class=\"w3-padding-16\">Floorplanning</li>\n" +
"        <li class=\"w3-padding-16\">50 hours support</li>\n" +
"        <li class=\"w3-padding-16\">Photography</li>\n" +
"        <li class=\"w3-padding-16\">50% furniture discount</li>\n" +
"        <li class=\"w3-padding-16\">GREAT deals</li>\n" +
"        <li class=\"w3-padding-16\">\n" +
"          <h2>$ 249</h2>\n" +
"          <span class=\"w3-opacity\">per room</span>\n" +
"        </li>\n" +
"        <li class=\"w3-light-grey w3-padding-24\">\n" +
"          <button class=\"w3-button w3-red w3-padding-large w3-hover-black\">Sign Up</button>\n" +
"        </li>\n" +
"      </ul>\n" +
"    </div>\n" +
"  </div>\n" +
"  \n" +
"  <!-- Contact -->\n" +
"  <div class=\"w3-container\" id=\"contact\" style=\"margin-top:75px\">\n" +
"    <h1 class=\"w3-xxxlarge w3-text-red\"><b>Contact.</b></h1>\n" +
"    <hr style=\"width:50px;border:5px solid red\" class=\"w3-round\">\n" +
"    <p>Do you want us to style your home? Fill out the form and fill me in with the details :) We love meeting new people!</p>\n" +
"    <form action=\"/action_page.php\" target=\"_blank\">\n" +
"      <div class=\"w3-section\">\n" +
"        <label>Name</label>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" name=\"Name\" required>\n" +
"      </div>\n" +
"      <div class=\"w3-section\">\n" +
"        <label>Email</label>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" name=\"Email\" required>\n" +
"      </div>\n" +
"      <div class=\"w3-section\">\n" +
"        <label>Message</label>\n" +
"        <input class=\"w3-input w3-border\" type=\"text\" name=\"Message\" required>\n" +
"      </div>\n" +
"      <button type=\"submit\" class=\"w3-button w3-block w3-padding-large w3-red w3-margin-bottom\">Send Message</button>\n" +
"    </form>  \n" +
"  </div>\n" +
"\n" +
"<!-- End page content -->\n" +
"</div>\n" +
"\n" +
"<!-- W3.CSS Container -->\n" +
"<div class=\"w3-light-grey w3-container w3-padding-32\" style=\"margin-top:75px;padding-right:58px\"><p class=\"w3-right\">Powered by <a href=\"https://www.w3schools.com/w3css/default.asp\" title=\"W3.CSS\" target=\"_blank\" class=\"w3-hover-opacity\">w3.css</a></p></div>\n" +
"\n" +
"<script>\n" +
"// Script to open and close sidebar\n" +
"function w3_open() {\n" +
"  document.getElementById(\"mySidebar\").style.display = \"block\";\n" +
"  document.getElementById(\"myOverlay\").style.display = \"block\";\n" +
"}\n" +
" \n" +
"function w3_close() {\n" +
"  document.getElementById(\"mySidebar\").style.display = \"none\";\n" +
"  document.getElementById(\"myOverlay\").style.display = \"none\";\n" +
"}\n" +
"\n" +
"// Modal Image Gallery\n" +
"function onClick(element) {\n" +
"  document.getElementById(\"img01\").src = element.src;\n" +
"  document.getElementById(\"modal01\").style.display = \"block\";\n" +
"  var captionText = document.getElementById(\"caption\");\n" +
"  captionText.innerHTML = element.alt;\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferHTML();
    }//GEN-LAST:event_jMenuItem46ActionPerformed

    private void jMenuItem47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem47ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("/* W3.CSS 4.13 June 2019 by Jan Egil and Borge Refsnes */\n" +
"html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}\n" +
"/* Extract from normalize.css by Nicolas Gallagher and Jonathan Neal git.io/normalize */\n" +
"html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}\n" +
"article,aside,details,figcaption,figure,footer,header,main,menu,nav,section{display:block}summary{display:list-item}\n" +
"audio,canvas,progress,video{display:inline-block}progress{vertical-align:baseline}\n" +
"audio:not([controls]){display:none;height:0}[hidden],template{display:none}\n" +
"a{background-color:transparent}a:active,a:hover{outline-width:0}\n" +
"abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}\n" +
"b,strong{font-weight:bolder}dfn{font-style:italic}mark{background:#ff0;color:#000}\n" +
"small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\n" +
"sub{bottom:-0.25em}sup{top:-0.5em}figure{margin:1em 40px}img{border-style:none}\n" +
"code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}hr{box-sizing:content-box;height:0;overflow:visible}\n" +
"button,input,select,textarea,optgroup{font:inherit;margin:0}optgroup{font-weight:bold}\n" +
"button,input{overflow:visible}button,select{text-transform:none}\n" +
"button,[type=button],[type=reset],[type=submit]{-webkit-appearance:button}\n" +
"button::-moz-focus-inner,[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner{border-style:none;padding:0}\n" +
"button:-moz-focusring,[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring{outline:1px dotted ButtonText}\n" +
"fieldset{border:1px solid #c0c0c0;margin:0 2px;padding:.35em .625em .75em}\n" +
"legend{color:inherit;display:table;max-width:100%;padding:0;white-space:normal}textarea{overflow:auto}\n" +
"[type=checkbox],[type=radio]{padding:0}\n" +
"[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}\n" +
"[type=search]{-webkit-appearance:textfield;outline-offset:-2px}\n" +
"[type=search]::-webkit-search-decoration{-webkit-appearance:none}\n" +
"::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}\n" +
"/* End extract */\n" +
"html,body{font-family:Verdana,sans-serif;font-size:15px;line-height:1.5}html{overflow-x:hidden}\n" +
"h1{font-size:36px}h2{font-size:30px}h3{font-size:24px}h4{font-size:20px}h5{font-size:18px}h6{font-size:16px}.w3-serif{font-family:serif}\n" +
"h1,h2,h3,h4,h5,h6{font-family:\"Segoe UI\",Arial,sans-serif;font-weight:400;margin:10px 0}.w3-wide{letter-spacing:4px}\n" +
"hr{border:0;border-top:1px solid #eee;margin:20px 0}\n" +
".w3-image{max-width:100%;height:auto}img{vertical-align:middle}a{color:inherit}\n" +
".w3-table,.w3-table-all{border-collapse:collapse;border-spacing:0;width:100%;display:table}.w3-table-all{border:1px solid #ccc}\n" +
".w3-bordered tr,.w3-table-all tr{border-bottom:1px solid #ddd}.w3-striped tbody tr:nth-child(even){background-color:#f1f1f1}\n" +
".w3-table-all tr:nth-child(odd){background-color:#fff}.w3-table-all tr:nth-child(even){background-color:#f1f1f1}\n" +
".w3-hoverable tbody tr:hover,.w3-ul.w3-hoverable li:hover{background-color:#ccc}.w3-centered tr th,.w3-centered tr td{text-align:center}\n" +
".w3-table td,.w3-table th,.w3-table-all td,.w3-table-all th{padding:8px 8px;display:table-cell;text-align:left;vertical-align:top}\n" +
".w3-table th:first-child,.w3-table td:first-child,.w3-table-all th:first-child,.w3-table-all td:first-child{padding-left:16px}\n" +
".w3-btn,.w3-button{border:none;display:inline-block;padding:8px 16px;vertical-align:middle;overflow:hidden;text-decoration:none;color:inherit;background-color:inherit;text-align:center;cursor:pointer;white-space:nowrap}\n" +
".w3-btn:hover{box-shadow:0 8px 16px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19)}\n" +
".w3-btn,.w3-button{-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}   \n" +
".w3-disabled,.w3-btn:disabled,.w3-button:disabled{cursor:not-allowed;opacity:0.3}.w3-disabled *,:disabled *{pointer-events:none}\n" +
".w3-btn.w3-disabled:hover,.w3-btn:disabled:hover{box-shadow:none}\n" +
".w3-badge,.w3-tag{background-color:#000;color:#fff;display:inline-block;padding-left:8px;padding-right:8px;text-align:center}.w3-badge{border-radius:50%}\n" +
".w3-ul{list-style-type:none;padding:0;margin:0}.w3-ul li{padding:8px 16px;border-bottom:1px solid #ddd}.w3-ul li:last-child{border-bottom:none}\n" +
".w3-tooltip,.w3-display-container{position:relative}.w3-tooltip .w3-text{display:none}.w3-tooltip:hover .w3-text{display:inline-block}\n" +
".w3-ripple:active{opacity:0.5}.w3-ripple{transition:opacity 0s}\n" +
".w3-input{padding:8px;display:block;border:none;border-bottom:1px solid #ccc;width:100%}\n" +
".w3-select{padding:9px 0;width:100%;border:none;border-bottom:1px solid #ccc}\n" +
".w3-dropdown-click,.w3-dropdown-hover{position:relative;display:inline-block;cursor:pointer}\n" +
".w3-dropdown-hover:hover .w3-dropdown-content{display:block}\n" +
".w3-dropdown-hover:first-child,.w3-dropdown-click:hover{background-color:#ccc;color:#000}\n" +
".w3-dropdown-hover:hover > .w3-button:first-child,.w3-dropdown-click:hover > .w3-button:first-child{background-color:#ccc;color:#000}\n" +
".w3-dropdown-content{cursor:auto;color:#000;background-color:#fff;display:none;position:absolute;min-width:160px;margin:0;padding:0;z-index:1}\n" +
".w3-check,.w3-radio{width:24px;height:24px;position:relative;top:6px}\n" +
".w3-sidebar{height:100%;width:200px;background-color:#fff;position:fixed!important;z-index:1;overflow:auto}\n" +
".w3-bar-block .w3-dropdown-hover,.w3-bar-block .w3-dropdown-click{width:100%}\n" +
".w3-bar-block .w3-dropdown-hover .w3-dropdown-content,.w3-bar-block .w3-dropdown-click .w3-dropdown-content{min-width:100%}\n" +
".w3-bar-block .w3-dropdown-hover .w3-button,.w3-bar-block .w3-dropdown-click .w3-button{width:100%;text-align:left;padding:8px 16px}\n" +
".w3-main,#main{transition:margin-left .4s}\n" +
".w3-modal{z-index:3;display:none;padding-top:100px;position:fixed;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:rgb(0,0,0);background-color:rgba(0,0,0,0.4)}\n" +
".w3-modal-content{margin:auto;background-color:#fff;position:relative;padding:0;outline:0;width:600px}\n" +
".w3-bar{width:100%;overflow:hidden}.w3-center .w3-bar{display:inline-block;width:auto}\n" +
".w3-bar .w3-bar-item{padding:8px 16px;float:left;width:auto;border:none;display:block;outline:0}\n" +
".w3-bar .w3-dropdown-hover,.w3-bar .w3-dropdown-click{position:static;float:left}\n" +
".w3-bar .w3-button{white-space:normal}\n" +
".w3-bar-block .w3-bar-item{width:100%;display:block;padding:8px 16px;text-align:left;border:none;white-space:normal;float:none;outline:0}\n" +
".w3-bar-block.w3-center .w3-bar-item{text-align:center}.w3-block{display:block;width:100%}\n" +
".w3-responsive{display:block;overflow-x:auto}\n" +
".w3-container:after,.w3-container:before,.w3-panel:after,.w3-panel:before,.w3-row:after,.w3-row:before,.w3-row-padding:after,.w3-row-padding:before,\n" +
".w3-cell-row:before,.w3-cell-row:after,.w3-clear:after,.w3-clear:before,.w3-bar:before,.w3-bar:after{content:\"\";display:table;clear:both}\n" +
".w3-col,.w3-half,.w3-third,.w3-twothird,.w3-threequarter,.w3-quarter{float:left;width:100%}\n" +
".w3-col.s1{width:8.33333%}.w3-col.s2{width:16.66666%}.w3-col.s3{width:24.99999%}.w3-col.s4{width:33.33333%}\n" +
".w3-col.s5{width:41.66666%}.w3-col.s6{width:49.99999%}.w3-col.s7{width:58.33333%}.w3-col.s8{width:66.66666%}\n" +
".w3-col.s9{width:74.99999%}.w3-col.s10{width:83.33333%}.w3-col.s11{width:91.66666%}.w3-col.s12{width:99.99999%}\n" +
"@media (min-width:601px){.w3-col.m1{width:8.33333%}.w3-col.m2{width:16.66666%}.w3-col.m3,.w3-quarter{width:24.99999%}.w3-col.m4,.w3-third{width:33.33333%}\n" +
".w3-col.m5{width:41.66666%}.w3-col.m6,.w3-half{width:49.99999%}.w3-col.m7{width:58.33333%}.w3-col.m8,.w3-twothird{width:66.66666%}\n" +
".w3-col.m9,.w3-threequarter{width:74.99999%}.w3-col.m10{width:83.33333%}.w3-col.m11{width:91.66666%}.w3-col.m12{width:99.99999%}}\n" +
"@media (min-width:993px){.w3-col.l1{width:8.33333%}.w3-col.l2{width:16.66666%}.w3-col.l3{width:24.99999%}.w3-col.l4{width:33.33333%}\n" +
".w3-col.l5{width:41.66666%}.w3-col.l6{width:49.99999%}.w3-col.l7{width:58.33333%}.w3-col.l8{width:66.66666%}\n" +
".w3-col.l9{width:74.99999%}.w3-col.l10{width:83.33333%}.w3-col.l11{width:91.66666%}.w3-col.l12{width:99.99999%}}\n" +
".w3-rest{overflow:hidden}.w3-stretch{margin-left:-16px;margin-right:-16px}\n" +
".w3-content,.w3-auto{margin-left:auto;margin-right:auto}.w3-content{max-width:980px}.w3-auto{max-width:1140px}\n" +
".w3-cell-row{display:table;width:100%}.w3-cell{display:table-cell}\n" +
".w3-cell-top{vertical-align:top}.w3-cell-middle{vertical-align:middle}.w3-cell-bottom{vertical-align:bottom}\n" +
".w3-hide{display:none!important}.w3-show-block,.w3-show{display:block!important}.w3-show-inline-block{display:inline-block!important}\n" +
"@media (max-width:1205px){.w3-auto{max-width:95%}}\n" +
"@media (max-width:600px){.w3-modal-content{margin:0 10px;width:auto!important}.w3-modal{padding-top:30px}\n" +
".w3-dropdown-hover.w3-mobile .w3-dropdown-content,.w3-dropdown-click.w3-mobile .w3-dropdown-content{position:relative}	\n" +
".w3-hide-small{display:none!important}.w3-mobile{display:block;width:100%!important}.w3-bar-item.w3-mobile,.w3-dropdown-hover.w3-mobile,.w3-dropdown-click.w3-mobile{text-align:center}\n" +
".w3-dropdown-hover.w3-mobile,.w3-dropdown-hover.w3-mobile .w3-btn,.w3-dropdown-hover.w3-mobile .w3-button,.w3-dropdown-click.w3-mobile,.w3-dropdown-click.w3-mobile .w3-btn,.w3-dropdown-click.w3-mobile .w3-button{width:100%}}\n" +
"@media (max-width:768px){.w3-modal-content{width:500px}.w3-modal{padding-top:50px}}\n" +
"@media (min-width:993px){.w3-modal-content{width:900px}.w3-hide-large{display:none!important}.w3-sidebar.w3-collapse{display:block!important}}\n" +
"@media (max-width:992px) and (min-width:601px){.w3-hide-medium{display:none!important}}\n" +
"@media (max-width:992px){.w3-sidebar.w3-collapse{display:none}.w3-main{margin-left:0!important;margin-right:0!important}.w3-auto{max-width:100%}}\n" +
".w3-top,.w3-bottom{position:fixed;width:100%;z-index:1}.w3-top{top:0}.w3-bottom{bottom:0}\n" +
".w3-overlay{position:fixed;display:none;width:100%;height:100%;top:0;left:0;right:0;bottom:0;background-color:rgba(0,0,0,0.5);z-index:2}\n" +
".w3-display-topleft{position:absolute;left:0;top:0}.w3-display-topright{position:absolute;right:0;top:0}\n" +
".w3-display-bottomleft{position:absolute;left:0;bottom:0}.w3-display-bottomright{position:absolute;right:0;bottom:0}\n" +
".w3-display-middle{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%)}\n" +
".w3-display-left{position:absolute;top:50%;left:0%;transform:translate(0%,-50%);-ms-transform:translate(-0%,-50%)}\n" +
".w3-display-right{position:absolute;top:50%;right:0%;transform:translate(0%,-50%);-ms-transform:translate(0%,-50%)}\n" +
".w3-display-topmiddle{position:absolute;left:50%;top:0;transform:translate(-50%,0%);-ms-transform:translate(-50%,0%)}\n" +
".w3-display-bottommiddle{position:absolute;left:50%;bottom:0;transform:translate(-50%,0%);-ms-transform:translate(-50%,0%)}\n" +
".w3-display-container:hover .w3-display-hover{display:block}.w3-display-container:hover span.w3-display-hover{display:inline-block}.w3-display-hover{display:none}\n" +
".w3-display-position{position:absolute}\n" +
".w3-circle{border-radius:50%}\n" +
".w3-round-small{border-radius:2px}.w3-round,.w3-round-medium{border-radius:4px}.w3-round-large{border-radius:8px}.w3-round-xlarge{border-radius:16px}.w3-round-xxlarge{border-radius:32px}\n" +
".w3-row-padding,.w3-row-padding>.w3-half,.w3-row-padding>.w3-third,.w3-row-padding>.w3-twothird,.w3-row-padding>.w3-threequarter,.w3-row-padding>.w3-quarter,.w3-row-padding>.w3-col{padding:0 8px}\n" +
".w3-container,.w3-panel{padding:0.01em 16px}.w3-panel{margin-top:16px;margin-bottom:16px}\n" +
".w3-code,.w3-codespan{font-family:Consolas,\"courier new\";font-size:16px}\n" +
".w3-code{width:auto;background-color:#fff;padding:8px 12px;border-left:4px solid #4CAF50;word-wrap:break-word}\n" +
".w3-codespan{color:crimson;background-color:#f1f1f1;padding-left:4px;padding-right:4px;font-size:110%}\n" +
".w3-card,.w3-card-2{box-shadow:0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)}\n" +
".w3-card-4,.w3-hover-shadow:hover{box-shadow:0 4px 10px 0 rgba(0,0,0,0.2),0 4px 20px 0 rgba(0,0,0,0.19)}\n" +
".w3-spin{animation:w3-spin 2s infinite linear}@keyframes w3-spin{0%{transform:rotate(0deg)}100%{transform:rotate(359deg)}}\n" +
".w3-animate-fading{animation:fading 10s infinite}@keyframes fading{0%{opacity:0}50%{opacity:1}100%{opacity:0}}\n" +
".w3-animate-opacity{animation:opac 0.8s}@keyframes opac{from{opacity:0} to{opacity:1}}\n" +
".w3-animate-top{position:relative;animation:animatetop 0.4s}@keyframes animatetop{from{top:-300px;opacity:0} to{top:0;opacity:1}}\n" +
".w3-animate-left{position:relative;animation:animateleft 0.4s}@keyframes animateleft{from{left:-300px;opacity:0} to{left:0;opacity:1}}\n" +
".w3-animate-right{position:relative;animation:animateright 0.4s}@keyframes animateright{from{right:-300px;opacity:0} to{right:0;opacity:1}}\n" +
".w3-animate-bottom{position:relative;animation:animatebottom 0.4s}@keyframes animatebottom{from{bottom:-300px;opacity:0} to{bottom:0;opacity:1}}\n" +
".w3-animate-zoom {animation:animatezoom 0.6s}@keyframes animatezoom{from{transform:scale(0)} to{transform:scale(1)}}\n" +
".w3-animate-input{transition:width 0.4s ease-in-out}.w3-animate-input:focus{width:100%!important}\n" +
".w3-opacity,.w3-hover-opacity:hover{opacity:0.60}.w3-opacity-off,.w3-hover-opacity-off:hover{opacity:1}\n" +
".w3-opacity-max{opacity:0.25}.w3-opacity-min{opacity:0.75}\n" +
".w3-greyscale-max,.w3-grayscale-max,.w3-hover-greyscale:hover,.w3-hover-grayscale:hover{filter:grayscale(100%)}\n" +
".w3-greyscale,.w3-grayscale{filter:grayscale(75%)}.w3-greyscale-min,.w3-grayscale-min{filter:grayscale(50%)}\n" +
".w3-sepia{filter:sepia(75%)}.w3-sepia-max,.w3-hover-sepia:hover{filter:sepia(100%)}.w3-sepia-min{filter:sepia(50%)}\n" +
".w3-tiny{font-size:10px!important}.w3-small{font-size:12px!important}.w3-medium{font-size:15px!important}.w3-large{font-size:18px!important}\n" +
".w3-xlarge{font-size:24px!important}.w3-xxlarge{font-size:36px!important}.w3-xxxlarge{font-size:48px!important}.w3-jumbo{font-size:64px!important}\n" +
".w3-left-align{text-align:left!important}.w3-right-align{text-align:right!important}.w3-justify{text-align:justify!important}.w3-center{text-align:center!important}\n" +
".w3-border-0{border:0!important}.w3-border{border:1px solid #ccc!important}\n" +
".w3-border-top{border-top:1px solid #ccc!important}.w3-border-bottom{border-bottom:1px solid #ccc!important}\n" +
".w3-border-left{border-left:1px solid #ccc!important}.w3-border-right{border-right:1px solid #ccc!important}\n" +
".w3-topbar{border-top:6px solid #ccc!important}.w3-bottombar{border-bottom:6px solid #ccc!important}\n" +
".w3-leftbar{border-left:6px solid #ccc!important}.w3-rightbar{border-right:6px solid #ccc!important}\n" +
".w3-section,.w3-code{margin-top:16px!important;margin-bottom:16px!important}\n" +
".w3-margin{margin:16px!important}.w3-margin-top{margin-top:16px!important}.w3-margin-bottom{margin-bottom:16px!important}\n" +
".w3-margin-left{margin-left:16px!important}.w3-margin-right{margin-right:16px!important}\n" +
".w3-padding-small{padding:4px 8px!important}.w3-padding{padding:8px 16px!important}.w3-padding-large{padding:12px 24px!important}\n" +
".w3-padding-16{padding-top:16px!important;padding-bottom:16px!important}.w3-padding-24{padding-top:24px!important;padding-bottom:24px!important}\n" +
".w3-padding-32{padding-top:32px!important;padding-bottom:32px!important}.w3-padding-48{padding-top:48px!important;padding-bottom:48px!important}\n" +
".w3-padding-64{padding-top:64px!important;padding-bottom:64px!important}\n" +
".w3-left{float:left!important}.w3-right{float:right!important}\n" +
".w3-button:hover{color:#000!important;background-color:#ccc!important}\n" +
".w3-transparent,.w3-hover-none:hover{background-color:transparent!important}\n" +
".w3-hover-none:hover{box-shadow:none!important}\n" +
"/* Colors */\n" +
".w3-amber,.w3-hover-amber:hover{color:#000!important;background-color:#ffc107!important}\n" +
".w3-aqua,.w3-hover-aqua:hover{color:#000!important;background-color:#00ffff!important}\n" +
".w3-blue,.w3-hover-blue:hover{color:#fff!important;background-color:#2196F3!important}\n" +
".w3-light-blue,.w3-hover-light-blue:hover{color:#000!important;background-color:#87CEEB!important}\n" +
".w3-brown,.w3-hover-brown:hover{color:#fff!important;background-color:#795548!important}\n" +
".w3-cyan,.w3-hover-cyan:hover{color:#000!important;background-color:#00bcd4!important}\n" +
".w3-blue-grey,.w3-hover-blue-grey:hover,.w3-blue-gray,.w3-hover-blue-gray:hover{color:#fff!important;background-color:#607d8b!important}\n" +
".w3-green,.w3-hover-green:hover{color:#fff!important;background-color:#4CAF50!important}\n" +
".w3-light-green,.w3-hover-light-green:hover{color:#000!important;background-color:#8bc34a!important}\n" +
".w3-indigo,.w3-hover-indigo:hover{color:#fff!important;background-color:#3f51b5!important}\n" +
".w3-khaki,.w3-hover-khaki:hover{color:#000!important;background-color:#f0e68c!important}\n" +
".w3-lime,.w3-hover-lime:hover{color:#000!important;background-color:#cddc39!important}\n" +
".w3-orange,.w3-hover-orange:hover{color:#000!important;background-color:#ff9800!important}\n" +
".w3-deep-orange,.w3-hover-deep-orange:hover{color:#fff!important;background-color:#ff5722!important}\n" +
".w3-pink,.w3-hover-pink:hover{color:#fff!important;background-color:#e91e63!important}\n" +
".w3-purple,.w3-hover-purple:hover{color:#fff!important;background-color:#9c27b0!important}\n" +
".w3-deep-purple,.w3-hover-deep-purple:hover{color:#fff!important;background-color:#673ab7!important}\n" +
".w3-red,.w3-hover-red:hover{color:#fff!important;background-color:#f44336!important}\n" +
".w3-sand,.w3-hover-sand:hover{color:#000!important;background-color:#fdf5e6!important}\n" +
".w3-teal,.w3-hover-teal:hover{color:#fff!important;background-color:#009688!important}\n" +
".w3-yellow,.w3-hover-yellow:hover{color:#000!important;background-color:#ffeb3b!important}\n" +
".w3-white,.w3-hover-white:hover{color:#000!important;background-color:#fff!important}\n" +
".w3-black,.w3-hover-black:hover{color:#fff!important;background-color:#000!important}\n" +
".w3-grey,.w3-hover-grey:hover,.w3-gray,.w3-hover-gray:hover{color:#000!important;background-color:#9e9e9e!important}\n" +
".w3-light-grey,.w3-hover-light-grey:hover,.w3-light-gray,.w3-hover-light-gray:hover{color:#000!important;background-color:#f1f1f1!important}\n" +
".w3-dark-grey,.w3-hover-dark-grey:hover,.w3-dark-gray,.w3-hover-dark-gray:hover{color:#fff!important;background-color:#616161!important}\n" +
".w3-pale-red,.w3-hover-pale-red:hover{color:#000!important;background-color:#ffdddd!important}\n" +
".w3-pale-green,.w3-hover-pale-green:hover{color:#000!important;background-color:#ddffdd!important}\n" +
".w3-pale-yellow,.w3-hover-pale-yellow:hover{color:#000!important;background-color:#ffffcc!important}\n" +
".w3-pale-blue,.w3-hover-pale-blue:hover{color:#000!important;background-color:#ddffff!important}\n" +
".w3-text-amber,.w3-hover-text-amber:hover{color:#ffc107!important}\n" +
".w3-text-aqua,.w3-hover-text-aqua:hover{color:#00ffff!important}\n" +
".w3-text-blue,.w3-hover-text-blue:hover{color:#2196F3!important}\n" +
".w3-text-light-blue,.w3-hover-text-light-blue:hover{color:#87CEEB!important}\n" +
".w3-text-brown,.w3-hover-text-brown:hover{color:#795548!important}\n" +
".w3-text-cyan,.w3-hover-text-cyan:hover{color:#00bcd4!important}\n" +
".w3-text-blue-grey,.w3-hover-text-blue-grey:hover,.w3-text-blue-gray,.w3-hover-text-blue-gray:hover{color:#607d8b!important}\n" +
".w3-text-green,.w3-hover-text-green:hover{color:#4CAF50!important}\n" +
".w3-text-light-green,.w3-hover-text-light-green:hover{color:#8bc34a!important}\n" +
".w3-text-indigo,.w3-hover-text-indigo:hover{color:#3f51b5!important}\n" +
".w3-text-khaki,.w3-hover-text-khaki:hover{color:#b4aa50!important}\n" +
".w3-text-lime,.w3-hover-text-lime:hover{color:#cddc39!important}\n" +
".w3-text-orange,.w3-hover-text-orange:hover{color:#ff9800!important}\n" +
".w3-text-deep-orange,.w3-hover-text-deep-orange:hover{color:#ff5722!important}\n" +
".w3-text-pink,.w3-hover-text-pink:hover{color:#e91e63!important}\n" +
".w3-text-purple,.w3-hover-text-purple:hover{color:#9c27b0!important}\n" +
".w3-text-deep-purple,.w3-hover-text-deep-purple:hover{color:#673ab7!important}\n" +
".w3-text-red,.w3-hover-text-red:hover{color:#f44336!important}\n" +
".w3-text-sand,.w3-hover-text-sand:hover{color:#fdf5e6!important}\n" +
".w3-text-teal,.w3-hover-text-teal:hover{color:#009688!important}\n" +
".w3-text-yellow,.w3-hover-text-yellow:hover{color:#d2be0e!important}\n" +
".w3-text-white,.w3-hover-text-white:hover{color:#fff!important}\n" +
".w3-text-black,.w3-hover-text-black:hover{color:#000!important}\n" +
".w3-text-grey,.w3-hover-text-grey:hover,.w3-text-gray,.w3-hover-text-gray:hover{color:#757575!important}\n" +
".w3-text-light-grey,.w3-hover-text-light-grey:hover,.w3-text-light-gray,.w3-hover-text-light-gray:hover{color:#f1f1f1!important}\n" +
".w3-text-dark-grey,.w3-hover-text-dark-grey:hover,.w3-text-dark-gray,.w3-hover-text-dark-gray:hover{color:#3a3a3a!important}\n" +
".w3-border-amber,.w3-hover-border-amber:hover{border-color:#ffc107!important}\n" +
".w3-border-aqua,.w3-hover-border-aqua:hover{border-color:#00ffff!important}\n" +
".w3-border-blue,.w3-hover-border-blue:hover{border-color:#2196F3!important}\n" +
".w3-border-light-blue,.w3-hover-border-light-blue:hover{border-color:#87CEEB!important}\n" +
".w3-border-brown,.w3-hover-border-brown:hover{border-color:#795548!important}\n" +
".w3-border-cyan,.w3-hover-border-cyan:hover{border-color:#00bcd4!important}\n" +
".w3-border-blue-grey,.w3-hover-border-blue-grey:hover,.w3-border-blue-gray,.w3-hover-border-blue-gray:hover{border-color:#607d8b!important}\n" +
".w3-border-green,.w3-hover-border-green:hover{border-color:#4CAF50!important}\n" +
".w3-border-light-green,.w3-hover-border-light-green:hover{border-color:#8bc34a!important}\n" +
".w3-border-indigo,.w3-hover-border-indigo:hover{border-color:#3f51b5!important}\n" +
".w3-border-khaki,.w3-hover-border-khaki:hover{border-color:#f0e68c!important}\n" +
".w3-border-lime,.w3-hover-border-lime:hover{border-color:#cddc39!important}\n" +
".w3-border-orange,.w3-hover-border-orange:hover{border-color:#ff9800!important}\n" +
".w3-border-deep-orange,.w3-hover-border-deep-orange:hover{border-color:#ff5722!important}\n" +
".w3-border-pink,.w3-hover-border-pink:hover{border-color:#e91e63!important}\n" +
".w3-border-purple,.w3-hover-border-purple:hover{border-color:#9c27b0!important}\n" +
".w3-border-deep-purple,.w3-hover-border-deep-purple:hover{border-color:#673ab7!important}\n" +
".w3-border-red,.w3-hover-border-red:hover{border-color:#f44336!important}\n" +
".w3-border-sand,.w3-hover-border-sand:hover{border-color:#fdf5e6!important}\n" +
".w3-border-teal,.w3-hover-border-teal:hover{border-color:#009688!important}\n" +
".w3-border-yellow,.w3-hover-border-yellow:hover{border-color:#ffeb3b!important}\n" +
".w3-border-white,.w3-hover-border-white:hover{border-color:#fff!important}\n" +
".w3-border-black,.w3-hover-border-black:hover{border-color:#000!important}\n" +
".w3-border-grey,.w3-hover-border-grey:hover,.w3-border-gray,.w3-hover-border-gray:hover{border-color:#9e9e9e!important}\n" +
".w3-border-light-grey,.w3-hover-border-light-grey:hover,.w3-border-light-gray,.w3-hover-border-light-gray:hover{border-color:#f1f1f1!important}\n" +
".w3-border-dark-grey,.w3-hover-border-dark-grey:hover,.w3-border-dark-gray,.w3-hover-border-dark-gray:hover{border-color:#616161!important}\n" +
".w3-border-pale-red,.w3-hover-border-pale-red:hover{border-color:#ffe7e7!important}.w3-border-pale-green,.w3-hover-border-pale-green:hover{border-color:#e7ffe7!important}\n" +
".w3-border-pale-yellow,.w3-hover-border-pale-yellow:hover{border-color:#ffffcc!important}.w3-border-pale-blue,.w3-hover-border-pale-blue:hover{border-color:#e7ffff!important}");
        transferCSS();
    }//GEN-LAST:event_jMenuItem47ActionPerformed

    private void jMenuItem48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem48ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<body>\n" +
"\n" +
"<div class=\"w3-container\">\n" +
"  <h2>Active Tabs</h2>\n" +
"  <p>To highlight the current tab/page the user is on, add a color class, and use JavaScript to update the active link.</p>\n" +
"\n" +
"  <div class=\"w3-bar w3-black\">\n" +
"    <button class=\"w3-bar-item w3-button tablink w3-red\" onclick=\"openCity(event,'London')\">London</button>\n" +
"    <button class=\"w3-bar-item w3-button tablink\" onclick=\"openCity(event,'Paris')\">Paris</button>\n" +
"    <button class=\"w3-bar-item w3-button tablink\" onclick=\"openCity(event,'Tokyo')\">Tokyo</button>\n" +
"  </div>\n" +
"  \n" +
"  <div id=\"London\" class=\"w3-container w3-border city\">\n" +
"    <h2>London</h2>\n" +
"    <p>London is the capital city of England.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Paris\" class=\"w3-container w3-border city\" style=\"display:none\">\n" +
"    <h2>Paris</h2>\n" +
"    <p>Paris is the capital of France.</p> \n" +
"  </div>\n" +
"\n" +
"  <div id=\"Tokyo\" class=\"w3-container w3-border city\" style=\"display:none\">\n" +
"    <h2>Tokyo</h2>\n" +
"    <p>Tokyo is the capital of Japan.</p>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openCity(evt, cityName) {\n" +
"  var i, x, tablinks;\n" +
"  x = document.getElementsByClassName(\"city\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    tablinks[i].className = tablinks[i].className.replace(\" w3-red\", \"\");\n" +
"  }\n" +
"  document.getElementById(cityName).style.display = \"block\";\n" +
"  evt.currentTarget.className += \" w3-red\";\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem48ActionPerformed

    private void jMenuItem49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem49ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<body>\n" +
"\n" +
"<div class=\"w3-sidebar w3-bar-block w3-light-grey w3-card\" style=\"width:130px\">\n" +
"  <h5 class=\"w3-bar-item\">Menu</h5>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openCity(event, 'London')\">London</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openCity(event, 'Paris')\">Paris</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openCity(event, 'Tokyo')\">Tokyo</button>\n" +
"</div>\n" +
"\n" +
"<div style=\"margin-left:130px\">\n" +
"  <div class=\"w3-padding\">Vertical Tab Example (sidebar)</div>\n" +
"\n" +
"  <div id=\"London\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>London</h2>\n" +
"    <p>London is the capital city of England.</p>\n" +
"    <p>It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Paris\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>Paris</h2>\n" +
"    <p>Paris is the capital of France.</p> \n" +
"    <p>The Paris area is one of the largest population centers in Europe, with more than 12 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Tokyo\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>Tokyo</h2>\n" +
"    <p>Tokyo is the capital of Japan.</p>\n" +
"    <p>It is the center of the Greater Tokyo Area, and the most populous metropolitan area in the world.</p>\n" +
"  </div>\n" +
"\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openCity(evt, cityName) {\n" +
"  var i, x, tablinks;\n" +
"  x = document.getElementsByClassName(\"city\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    tablinks[i].className = tablinks[i].className.replace(\" w3-red\", \"\"); \n" +
"  }\n" +
"  document.getElementById(cityName).style.display = \"block\";\n" +
"  evt.currentTarget.className += \" w3-red\";\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem49ActionPerformed

    private void jMenuItem55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem55ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<body>\n" +
"\n" +
"<div class=\"w3-sidebar w3-bar-block w3-black w3-card\" style=\"width:130px\">\n" +
"  <h5 class=\"w3-bar-item\">Menu</h5>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Fade')\">Fade</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Left')\">Left</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Right')\">Right</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Top')\">Top</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Bottom')\">Bottom</button>\n" +
"  <button class=\"w3-bar-item w3-button tablink\" onclick=\"openLink(event, 'Zoom')\">Zoom</button>\n" +
"</div>\n" +
"\n" +
"<div style=\"margin-left:130px\">\n" +
"  <div class=\"w3-padding\">Use any of the w3-animate-classes to fade, zoom or slide in tab content.</div>\n" +
"\n" +
"  <div id=\"Fade\" class=\"w3-container city w3-animate-opacity\" style=\"display:none\">\n" +
"    <h2>Fade in</h2>\n" +
"    <p>London is the capital city of England.</p>\n" +
"    <p>It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Left\" class=\"w3-container city w3-animate-left\" style=\"display:none\">\n" +
"    <h2>Slide in from left</h2>\n" +
"    <p>Paris is the capital of France.</p> \n" +
"    <p>The Paris area is one of the largest population centers in Europe, with more than 12 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Top\" class=\"w3-container city w3-animate-top\" style=\"display:none\">\n" +
"    <h2>Slide in from top</h2>\n" +
"    <p>Tokyo is the capital of Japan.</p>\n" +
"    <p>It is the center of the Greater Tokyo Area, and the most populous metropolitan area in the world.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Right\" class=\"w3-container city w3-animate-right\" style=\"display:none\">\n" +
"    <h2>Slide in from right</h2>\n" +
"    <p>London is the capital city of England.</p>\n" +
"    <p>It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Bottom\" class=\"w3-container city w3-animate-bottom\" style=\"display:none\">\n" +
"    <h2>Slide in from bottom</h2>\n" +
"    <p>Paris is the capital of France.</p> \n" +
"    <p>The Paris area is one of the largest population centers in Europe, with more than 12 million inhabitants.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Zoom\" class=\"w3-container city w3-animate-zoom\" style=\"display:none\">\n" +
"    <h2>Zoom in</h2>\n" +
"    <p>Tokyo is the capital of Japan.</p>\n" +
"    <p>It is the center of the Greater Tokyo Area, and the most populous metropolitan area in the world.</p>\n" +
"  </div>\n" +
"\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openLink(evt, animName) {\n" +
"  var i, x, tablinks;\n" +
"  x = document.getElementsByClassName(\"city\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    tablinks[i].className = tablinks[i].className.replace(\" w3-red\", \"\");\n" +
"  }\n" +
"  document.getElementById(animName).style.display = \"block\";\n" +
"  evt.currentTarget.className += \" w3-red\";\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem55ActionPerformed

    private void jMenuItem56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem56ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<body>\n" +
"\n" +
"<div class=\"w3-container\">\n" +
"  <h2>Tabbed Image Gallery</h2>\n" +
"  <p>Click on the images below:</p>\n" +
"</div>\n" +
"\n" +
"<div class=\"w3-row-padding\">\n" +
"  <div class=\"w3-col s3 w3-container\">\n" +
"  <a href=\"javascript:void(0)\" class=\"w3-hover-opacity\" onclick=\"openImg('Nature');\">\n" +
"    <img src=\"img_nature.jpg\" alt=\"Nature\" style=\"width:100%\">\n" +
"  </a>\n" +
"  </div>\n" +
"  <div class=\"w3-col s3 w3-container\">\n" +
"    <a href=\"javascript:void(0)\" class=\"w3-hover-opacity\" onclick=\"openImg('Snow');\">\n" +
"      <img src=\"img_snowtops.jpg\" alt=\"Snow\" style=\"width:100%\">\n" +
"    </a>\n" +
"  </div>\n" +
"  <div class=\"w3-col s3 w3-container\">\n" +
"    <a href=\"javascript:void(0)\" class=\"w3-hover-opacity\" onclick=\"openImg('Mountains');\">\n" +
"      <img src=\"img_mountains.jpg\" alt=\"Mountains\" style=\"width:100%\">\n" +
"    </a>\n" +
"  </div>\n" +
"  <div class=\"w3-col s3 w3-container\">\n" +
"    <a href=\"javascript:void(0)\" class=\"w3-hover-opacity\" onclick=\"openImg('Lights');\">\n" +
"      <img src=\"img_lights.jpg\" alt=\"Lights\" style=\"width:100%\">\n" +
"    </a>\n" +
"  </div>\n" +
"</div><br>\n" +
"\n" +
"<div id=\"Nature\" class=\"picture w3-display-container\" style=\"display:none\">\n" +
"  <img src=\"img_nature_wide.jpg\" alt=\"Nature\" style=\"width:100%\">\n" +
"  <span onclick=\"this.parentElement.style.display='none'\" \n" +
"  class=\"w3-display-topright w3-button w3-transparent w3-text-white\">&times;</span>\n" +
"  <div class=\"w3-display-bottomleft w3-container w3-padding w3-text-white\">Nature</div>\n" +
"</div>\n" +
"\n" +
"<div id=\"Snow\" class=\"picture w3-display-container\" style=\"display:none\">\n" +
"  <img src=\"img_snow_wide.jpg\" alt=\"Snow\" style=\"width:100%\">\n" +
"  <span onclick=\"this.parentElement.style.display='none'\" \n" +
"  class=\"w3-display-topright w3-button w3-transparent w3-text-white\">&times;</span>\n" +
"  <div class=\"w3-display-bottomleft w3-container w3-padding w3-text-white\">Snow</div>\n" +
"</div>\n" +
"\n" +
"<div id=\"Mountains\" class=\"picture w3-display-container\" style=\"display:none\">\n" +
"  <img src=\"img_mountains_wide.jpg\" alt=\"Mountains\" style=\"width:100%\">\n" +
"  <span onclick=\"this.parentElement.style.display='none'\" \n" +
"  class=\"w3-display-topright w3-button w3-transparent\">&times;</span>\n" +
"  <div class=\"w3-display-bottomleft w3-container w3-padding w3-text-white\">Mountains</div>\n" +
"</div>\n" +
"\n" +
"<div id=\"Lights\" class=\"picture w3-display-container\" style=\"display:none\">\n" +
"  <img src=\"img_lights_wide.jpg\" alt=\"Lights\" style=\"width:100%\">\n" +
"  <span onclick=\"this.parentElement.style.display='none'\" \n" +
"  class=\"w3-display-topright w3-button w3-transparent w3-text-white\">&times;</span>\n" +
"  <div class=\"w3-display-bottomleft w3-container w3-padding w3-text-white\">Northern Lights</div>\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openImg(imgName) {\n" +
"  var i, x;\n" +
"  x = document.getElementsByClassName(\"picture\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  document.getElementById(imgName).style.display = \"block\";\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html> ");
        transferCSS();
    }//GEN-LAST:event_jMenuItem56ActionPerformed

    private void jMenuItem57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem57ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<title>W3.CSS</title>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">\n" +
"<body>\n" +
"\n" +
"<div class=\"w3-container\">\n" +
"  <h2>Tabs in a Grid</h2>\n" +
"\n" +
"  <div class=\"w3-row\">\n" +
"    <a href=\"javascript:void(0)\" onclick=\"openCity(event, 'London');\">\n" +
"      <div class=\"w3-third tablink w3-bottombar w3-hover-light-grey w3-padding\">London</div>\n" +
"    </a>\n" +
"    <a href=\"javascript:void(0)\" onclick=\"openCity(event, 'Paris');\">\n" +
"      <div class=\"w3-third tablink w3-bottombar w3-hover-light-grey w3-padding\">Paris</div>\n" +
"    </a>\n" +
"    <a href=\"javascript:void(0)\" onclick=\"openCity(event, 'Tokyo');\">\n" +
"      <div class=\"w3-third tablink w3-bottombar w3-hover-light-grey w3-padding\">Tokyo</div>\n" +
"    </a>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"London\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>London</h2>\n" +
"    <p>London is the capital city of England.</p>\n" +
"  </div>\n" +
"\n" +
"  <div id=\"Paris\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>Paris</h2>\n" +
"    <p>Paris is the capital of France.</p> \n" +
"  </div>\n" +
"\n" +
"  <div id=\"Tokyo\" class=\"w3-container city\" style=\"display:none\">\n" +
"    <h2>Tokyo</h2>\n" +
"    <p>Tokyo is the capital of Japan.</p>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openCity(evt, cityName) {\n" +
"  var i, x, tablinks;\n" +
"  x = document.getElementsByClassName(\"city\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    x[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < x.length; i++) {\n" +
"    tablinks[i].className = tablinks[i].className.replace(\" w3-border-red\", \"\");\n" +
"  }\n" +
"  document.getElementById(cityName).style.display = \"block\";\n" +
"  evt.currentTarget.firstElementChild.className += \" w3-border-red\";\n" +
"}\n" +
"</script>\n" +
"\n" +
"</body>\n" +
"</html>");
        transferCSS();
    }//GEN-LAST:event_jMenuItem57ActionPerformed

    private void jMenuItem58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem58ActionPerformed
        // TODO add your handling code here:
        jTextArea4.setText("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
"<style>\n" +
"* {box-sizing: border-box}\n" +
"\n" +
"/* Set height of body and the document to 100% */\n" +
"body, html {\n" +
"  height: 100%;\n" +
"  margin: 0;\n" +
"  font-family: Arial;\n" +
"}\n" +
"\n" +
"/* Style tab links */\n" +
".tablink {\n" +
"  background-color: #555;\n" +
"  color: white;\n" +
"  float: left;\n" +
"  border: none;\n" +
"  outline: none;\n" +
"  cursor: pointer;\n" +
"  padding: 14px 16px;\n" +
"  font-size: 17px;\n" +
"  width: 25%;\n" +
"}\n" +
"\n" +
".tablink:hover {\n" +
"  background-color: #777;\n" +
"}\n" +
"\n" +
"/* Style the tab content (and add height:100% for full page content) */\n" +
".tabcontent {\n" +
"  color: white;\n" +
"  display: none;\n" +
"  padding: 100px 20px;\n" +
"  height: 100%;\n" +
"}\n" +
"\n" +
"#Home {background-color: red;}\n" +
"#News {background-color: green;}\n" +
"#Contact {background-color: blue;}\n" +
"#About {background-color: orange;}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<button class=\"tablink\" onclick=\"openPage('Home', this, 'red')\">Home</button>\n" +
"<button class=\"tablink\" onclick=\"openPage('News', this, 'green')\" id=\"defaultOpen\">News</button>\n" +
"<button class=\"tablink\" onclick=\"openPage('Contact', this, 'blue')\">Contact</button>\n" +
"<button class=\"tablink\" onclick=\"openPage('About', this, 'orange')\">About</button>\n" +
"\n" +
"<div id=\"Home\" class=\"tabcontent\">\n" +
"  <h3>Home</h3>\n" +
"  <p>Home is where the heart is..</p>\n" +
"</div>\n" +
"\n" +
"<div id=\"News\" class=\"tabcontent\">\n" +
"  <h3>News</h3>\n" +
"  <p>Some news this fine day!</p> \n" +
"</div>\n" +
"\n" +
"<div id=\"Contact\" class=\"tabcontent\">\n" +
"  <h3>Contact</h3>\n" +
"  <p>Get in touch, or swing by for a cup of coffee.</p>\n" +
"</div>\n" +
"\n" +
"<div id=\"About\" class=\"tabcontent\">\n" +
"  <h3>About</h3>\n" +
"  <p>Who we are and what we do.</p>\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"function openPage(pageName,elmnt,color) {\n" +
"  var i, tabcontent, tablinks;\n" +
"  tabcontent = document.getElementsByClassName(\"tabcontent\");\n" +
"  for (i = 0; i < tabcontent.length; i++) {\n" +
"    tabcontent[i].style.display = \"none\";\n" +
"  }\n" +
"  tablinks = document.getElementsByClassName(\"tablink\");\n" +
"  for (i = 0; i < tablinks.length; i++) {\n" +
"    tablinks[i].style.backgroundColor = \"\";\n" +
"  }\n" +
"  document.getElementById(pageName).style.display = \"block\";\n" +
"  elmnt.style.backgroundColor = color;\n" +
"}\n" +
"\n" +
"// Get the element with id=\"defaultOpen\" and click on it\n" +
"document.getElementById(\"defaultOpen\").click();\n" +
"</script>\n" +
"   \n" +
"</body>\n" +
"</html> ");
        transferCSS();
    }//GEN-LAST:event_jMenuItem58ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CodelodeonSwingpad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CodelodeonSwingpad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CodelodeonSwingpad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CodelodeonSwingpad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CodelodeonSwingpad().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCSSClose;
    private javax.swing.JButton jButtonCSSNew;
    private javax.swing.JButton jButtonCSSOpen;
    private javax.swing.JButton jButtonCSSRedo;
    private javax.swing.JButton jButtonCSSSave;
    private javax.swing.JButton jButtonCSSSaveAs;
    private javax.swing.JButton jButtonCSSUndo;
    private javax.swing.JButton jButtonHTMLClose;
    private javax.swing.JButton jButtonHTMLNew;
    private javax.swing.JButton jButtonHTMLOpen;
    private javax.swing.JButton jButtonHTMLRedo;
    private javax.swing.JButton jButtonHTMLSave;
    private javax.swing.JButton jButtonHTMLSaveAs;
    private javax.swing.JButton jButtonHTMLUndo;
    private javax.swing.JButton jButtonJSClose;
    private javax.swing.JButton jButtonJSNew;
    private javax.swing.JButton jButtonJSOpen;
    private javax.swing.JButton jButtonJSRedo;
    private javax.swing.JButton jButtonJSSave;
    private javax.swing.JButton jButtonJSSaveAs;
    private javax.swing.JButton jButtonJSUndo;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JDesktopPane jDesktopPane2;
    private javax.swing.JDesktopPane jDesktopPane3;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JLayeredPane jLayeredPane3;
    private javax.swing.JLayeredPane jLayeredPane4;
    private javax.swing.JLayeredPane jLayeredPane5;
    private javax.swing.JLayeredPane jLayeredPane6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu13;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem15;
    private javax.swing.JMenuItem jMenuItem16;
    private javax.swing.JMenuItem jMenuItem17;
    private javax.swing.JMenuItem jMenuItem18;
    private javax.swing.JMenuItem jMenuItem19;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem20;
    private javax.swing.JMenuItem jMenuItem21;
    private javax.swing.JMenuItem jMenuItem22;
    private javax.swing.JMenuItem jMenuItem23;
    private javax.swing.JMenuItem jMenuItem24;
    private javax.swing.JMenuItem jMenuItem25;
    private javax.swing.JMenuItem jMenuItem26;
    private javax.swing.JMenuItem jMenuItem27;
    private javax.swing.JMenuItem jMenuItem28;
    private javax.swing.JMenuItem jMenuItem29;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem30;
    private javax.swing.JMenuItem jMenuItem31;
    private javax.swing.JMenuItem jMenuItem32;
    private javax.swing.JMenuItem jMenuItem33;
    private javax.swing.JMenuItem jMenuItem34;
    private javax.swing.JMenuItem jMenuItem35;
    private javax.swing.JMenuItem jMenuItem36;
    private javax.swing.JMenuItem jMenuItem37;
    private javax.swing.JMenuItem jMenuItem38;
    private javax.swing.JMenuItem jMenuItem39;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem40;
    private javax.swing.JMenuItem jMenuItem41;
    private javax.swing.JMenuItem jMenuItem42;
    private javax.swing.JMenuItem jMenuItem43;
    private javax.swing.JMenuItem jMenuItem44;
    private javax.swing.JMenuItem jMenuItem45;
    private javax.swing.JMenuItem jMenuItem46;
    private javax.swing.JMenuItem jMenuItem47;
    private javax.swing.JMenuItem jMenuItem48;
    private javax.swing.JMenuItem jMenuItem49;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem50;
    private javax.swing.JMenuItem jMenuItem51;
    private javax.swing.JMenuItem jMenuItem52;
    private javax.swing.JMenuItem jMenuItem53;
    private javax.swing.JMenuItem jMenuItem54;
    private javax.swing.JMenuItem jMenuItem55;
    private javax.swing.JMenuItem jMenuItem56;
    private javax.swing.JMenuItem jMenuItem57;
    private javax.swing.JMenuItem jMenuItem58;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JMenuItem jMenuItemA;
    private javax.swing.JMenuItem jMenuItemB;
    private javax.swing.JMenuItem jMenuItemC;
    private javax.swing.JMenuItem jMenuItemD;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JToolBar jToolBar3;
    // End of variables declaration//GEN-END:variables
}
